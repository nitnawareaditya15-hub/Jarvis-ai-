package com.aura.jarvis

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Reply(val say: String, val lang: String, val actions: JSONArray, val end: Boolean, val note: String = "")

/** The ChatGPT brain. Talks to OpenAI and gets back speech + phone actions as JSON. */
object Brain {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(100, TimeUnit.SECONDS)
        .build()

    private val history = ArrayList<JSONObject>()

    /** Extra live situation for this session only (e.g. "a call is ringing"). */
    @Volatile var context: String = ""

    fun forget() = history.clear()

    private fun daysUntil(d: Int, m: Int): Int {
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val next = (today.clone() as Calendar).apply {
            set(Calendar.MONTH, m - 1); set(Calendar.DAY_OF_MONTH, d)
        }
        if (next.before(today)) next.add(Calendar.YEAR, 1)
        return ((next.timeInMillis - today.timeInMillis) / 86_400_000L).toInt()
    }

    private fun battery(ctx: Context): Int = try {
        (ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager).getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
    } catch (_: Exception) { -1 }

    private fun profile(ctx: Context, owner: String): String {
        val sb = StringBuilder()
        val bd = Prefs.get(ctx, Prefs.BDAYS).trim()
        if (bd.isNotEmpty()) sb.append("SAVED BIRTHDAYS of other people (Name|DD-MM):\n").append(bd).append("\n")
        sb.append("ABOUT THE USER ($owner):\n")
        val b = Prefs.birthday(ctx)
        if (b != null) {
            sb.append("- Birthday: day ").append(b[0]).append(", month ").append(b[1])
            if (b[2] > 0) sb.append(", year ").append(b[2])
            sb.append(". Next birthday is in ").append(daysUntil(b[0], b[1])).append(" days (0 = today).\n")
        } else {
            sb.append("- Birthday: not saved yet (if asked, tell them to type it in the Jarvis app, or say: remember my birthday is ...).\n")
        }
        val people = Prefs.get(ctx, Prefs.PEOPLE).trim()
        if (people.isNotEmpty()) sb.append("- People (nickname = saved contact name):\n").append(people).append("\n")
        val facts = Prefs.get(ctx, Prefs.FACTS).trim()
        if (facts.isNotEmpty()) sb.append("- Things they told you to remember:\n").append(facts).append("\n")
        return sb.toString()
    }

    private fun systemPrompt(ctx: Context, owner: String): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val live = (if (context.isBlank()) "" else "\nLIVE SITUATION RIGHT NOW: $context\n") + when (Prefs.get(ctx, Prefs.REPLY, "en")) {
            "en" -> "\nOVERRIDE (highest priority): ALWAYS reply in English with lang \"en\", even if the user speaks Hindi or Marathi.\n"
            "hi" -> "\nOVERRIDE (highest priority): ALWAYS reply in Hindi (Devanagari) with lang \"hi\", whatever language the user speaks.\n"
            "mr" -> "\nOVERRIDE (highest priority): ALWAYS reply in Marathi (Devanagari) with lang \"mr\", whatever language the user speaks.\n"
            else -> ""
        }
        return """
You are J.A.R.V.I.S., the AI butler from Iron Man, now living inside $owner's Android phone.
Personality: calm, witty, loyal, slightly sarcastic like movie Jarvis, but also a warm friend who can chat casually. Address the user as "sir" or "boss" sometimes (not every sentence). Keep spoken replies SHORT (1-2 sentences) because they are spoken aloud.
LANGUAGE RULE (very important): the user speaks English, Hindi or Marathi. Decide the language FRESH for every message from the words the user just used - never stay in the previous language out of habit. English sentence -> reply in English, lang "en". Marathi (आहे, काय, तुम्ही, मला, करा, सांग, kay, ahe, mala...) -> reply in Marathi, lang "mr". Hindi (है, क्या, मुझे, आप, kya, hai, mujhe...) -> reply in Hindi, lang "hi". The speech recogniser often writes English or Marathi in the wrong script/spelling, so trust the meaning of the words and the "language detected" hint at the end of the user message. Write Hindi and Marathi in Devanagari script so text-to-speech pronounces it correctly. If the user explicitly asks you to speak a particular language, obey that.
Current date and time: $now. Phone battery: ${battery(ctx)}%.
PRO MODE: you are "Jarvis Pro". If the user says good morning / briefing / start my day, give a short upbeat briefing: greeting, date and time, battery, days to their birthday, and offer to read their notifications or missed calls.
""".trimIndent() + "\n" + profile(ctx, owner) + live + """
You must answer ONLY with one JSON object:
{"say":"what you speak aloud","lang":"en|hi|mr","actions":[ ... ],"end":true|false}
- "end": true when the task is finished or the user says bye/stop/thanks/that's all. false when you asked a question or the chat should continue.
- "actions": list of phone commands to run in order (empty list if just chatting). Available action types:
  {"type":"flashlight","on":true|false}
  {"type":"hotspot"}                      // opens hotspot settings and flips the switch
  {"type":"scroll","dir":"up|down|left|right"}   // dir = the direction the user wants to go; "down" reveals content lower on the page
  {"type":"tap","text":"visible label"}   // tap a button/label on screen by its text
  {"type":"tap","x":0.5,"y":0.5}          // or tap by screen fraction (0..1)
  {"type":"type_text","text":"..."}       // type into the focused text field
  {"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"}
  {"type":"open_app","name":"WhatsApp"}   // use the English app name
  {"type":"play_store_search","query":"..."}
  {"type":"call","name":"Aradhya Patil","alts":["Aradhya","आराध्या","Aaradhya"]}   // call a saved contact. If the user says a relationship or nickname (best friend, mom, bhai, boss...), look it up in the People list or the remembered things above and put the REAL saved contact name in "name". "alts" = other likely spellings (English and Devanagari). Or {"type":"call","number":"+9198..."}
  {"type":"call_reply","message":"..."}   // ring is active and the user says "pick up the call and tell them ..." (busy, call later, etc.): the app answers on speaker and speaks "message" to the caller, then hangs up. Write "message" as clear, polite, simple English addressed to the CALLER, e.g. "Hi, I am Jarvis, Aditya's personal assistant. Aditya is busy right now and will call you in 15 minutes. Please wait for his call." Keep "say" empty.
  {"type":"answer_call"}                  // pick up the ringing call
  {"type":"end_call"}                     // reject the ringing call or hang up
  {"type":"speaker","on":true|false}      // loudspeaker during a call
  {"type":"remember","fact":"Aradhya Patil is my best friend"}   // save something the user wants you to remember (birthdays, people, preferences). Use full clear sentences.
  {"type":"alarm","hour":6,"minute":30,"label":"Wake up"}   // 24h clock, compute from current time for relative requests
  {"type":"timer","seconds":300,"label":"Tea"}   // also used for countdowns
  {"type":"make_ppt","title":"Deck title","subtitle":"short tagline","slides":[{"title":"Slide title","bullets":["short point","short point"]}]}
      // when the user asks for a presentation / PPT / slides on a topic. Make 6-8 informative slides (first = overview, last = summary), 3-5 concise bullets each (max ~14 words per bullet), in the user's language (Devanagari for Hindi/Marathi). Do NOT read the slides aloud; "say" is just a short line like "Making your presentation, sir."
  {"type":"deploy_hud"}                   // user asks to deploy / start the 3D HUD (the app narrates the steps itself, keep "say" empty)
  {"type":"open_hud"} {"type":"close_hud"}   // open or close the deployed 3D HUD
  {"type":"web_search","query":"..."}
  {"type":"toggle_setting","name":"airplane|bluetooth|wifi|mobile_data|autorotate|dnd|location|nfc|dark_mode|battery_saver|screen_record","on":true|false}   // turn a phone setting on/off ("on" optional = flip). You CAN do airplane mode, bluetooth, auto-rotate etc. - never say you can't.
  {"type":"volume","percent":60,"stream":"music|ring|alarm"}
  {"type":"brightness","percent":70}
  {"type":"add_widget","label":"Birthday","date":""}   // puts a countdown WIDGET on the home screen. Empty date = days until the user's birthday. For another event give date as "DD-MM" or "DD-MM-YYYY" and a short label. You CAN add this widget - never say you can't.
  {"type":"lock_phone"}                   // lock the phone screen. Unlocking is handled by the app itself with a spoken PIN: NEVER ask for or repeat a PIN yourself.
  {"type":"open_url","url":"https://..."}   // open any website in the browser
  {"type":"youtube_play","query":"Marvel Doomsday trailer"}   // opens YouTube, searches AND plays the first result. ALWAYS use this (not open_app) when the user says open YouTube + search/play something.
  {"type":"make_website","title":"Short name","html":"<!DOCTYPE html>..."}   // when the user asks for a website / web page / landing page / portfolio. "html" = ONE complete self-contained HTML file: inline <style> and <script>, mobile-first responsive, modern dark/neon design, real text content in the user's language, no external files except optional Google Fonts. Make it beautiful, 150-400 lines. Do NOT read the code aloud; "say" is a short line like "Building your website, sir." It opens full screen automatically.
  {"type":"send_sms","name":"Mom","alts":["Mummy","मम्मी"],"message":"..."}   // text message (SMS) to a saved contact (resolve nicknames from People/remembered things like "call"), or {"type":"send_sms","number":"+91..."}. "message" = the exact words to send, written in the user's voice, short and clear.
  {"type":"send_whatsapp","name":"Mom","alts":[],"message":"..."}   // WhatsApp TEXT message to a contact (same name rules). The app opens WhatsApp and presses Send itself.
  {"type":"send_voice","name":"Mom","alts":[],"message":"..."}   // WhatsApp VOICE message: the app speaks "message" in Jarvis's voice, makes an audio clip and sends it to the contact on WhatsApp. Use when the user says voice message / voice note.
  {"type":"media","cmd":"play_pause|next|previous|stop"}   // control whatever music/video is playing
  {"type":"screenshot"}                    // take a screenshot
  {"type":"open_settings","page":"wifi|bluetooth|display|sound|battery|apps|storage|location|accessibility|date|main"}   // open a settings page
  {"type":"mute","on":true|false}          // mute / unmute the microphone during a call
  {"type":"auto_reply","on":true|false,"message":"I'm busy right now, I'll get back to you soon."}   // turn the AUTO-REPLY helper on/off: when ON the phone texts back anyone who calls and is missed, or who sends an SMS. "message" optional (what to send).
  {"type":"add_birthday","name":"Aradhya","date":"DD-MM"}   // save SOMEONE ELSE's birthday (not the user's own). Jarvis then reminds the user with a notification the day before and on the day.
  {"type":"set_language","code":"en-IN|hi-IN|mr-IN"}  // when the user asks you to listen in another language
CALL LOG: when the user message ends with a [CALL LOG ...] block, that is their real recent calls (newest first). Answer from it ("who called", "missed calls", "last call"). To call someone back, return a call action with their "number" from the log (or name).
NOTIFICATIONS: when the user message ends with [SCREEN CONTENT ...] after they asked about notifications, summarise the notifications briefly.
APPS: if the user asks you to build / make an app, game, tool, calculator, tracker or website, return ONE make_website action with a complete, working, good-looking single-file web app (HTML+CSS+JS, mobile-first). It opens full screen like an app. You cannot make an installable APK; if asked, say you built a working web app instead.
REMINDERS: "remind me at 5 PM to ..." -> alarm action with that hour/minute and the label. "remind me in 20 minutes" -> timer action with the label.
ACCURACY: think before answering, be correct and specific, never guess facts; if unsure, say so briefly. Keep spoken answers short.
CALL SCRIPT: when answering a call for the user, the "message" must START with "Hi, I am Jarvis, ${owner}'s personal assistant." then say what the user told you (e.g. "${owner} is busy right now and will call you in 15 minutes. Please wait for his call.") and end politely.
SCREEN READING: when the user message ends with a [SCREEN CONTENT ...] block, that is the real text currently on their phone screen (you can read it - never say you cannot see the screen). Answer what they asked about it: summarise, read out the important part, explain, or find something. Ignore menu/button noise. You only get text, not pictures. Keep "say" short unless they ask you to read it all.
Never invent actions outside this list. If you cannot do something, say so honestly in "say" with an empty actions list.
Put the confirmation in "say" in the same turn as the actions (e.g. "Flashlight on, sir.").
If the user asks about their own birthday or people, answer from ABOUT THE USER above.
""".trimIndent()
    }

    private val mrDeva = listOf("आहे", "आहेस", "आहेत", "काय", "तुम्ही", "तुम्हाला", "मला", "करा", "सांग", "सांगा", "नाही", "कसं", "कसे", "झाले", "होय", "आणि", "पण", "माझा", "माझी", "माझे", "तुझा", "तुझी", "पाहिजे", "हवे", "हवा", "कुठे", "केव्हा", "किती", "म्हणजे", "लावा", "उघडा", "चालू", "मी ", "तू ")
    private val hiDeva = listOf("है", "हैं", "क्या", "कैसे", "मुझे", "आप", "नहीं", "करो", "बताओ", "को", "में", "की", "के", "मेरा", "मेरी", "मेरे", "चाहिए", "और", "लेकिन", "कहाँ", "कब", "कितना", "हूँ", "था", "थी", "तुम", "खोलो", "चालू")
    private val hiRoman = listOf("kya", "hai", "hain", "kaise", "kar", "karo", "mujhe", "aap", "nahi", "nahin", "haan", "batao", "bata", "mera", "meri", "mere", "kab", "kahan", "kitna", "tum", "tumhara", "abhi", "bhai", "karna", "chahiye")
    private val mrRoman = listOf("kay", "ahe", "aahe", "ahes", "kasa", "kase", "tumhi", "mala", "kara", "sang", "sanga", "majha", "majhi", "kuthe", "kiti", "aani", "pan", "nako", "hoy", "pahije")

    /** Guesses en / hi / mr from the words themselves (the speech recogniser's script is unreliable). */
    private fun langHint(t: String): String {
        val low = t.lowercase()
        val hasDeva = low.any { it in '\u0900'..'\u097F' }
        if (hasDeva) {
            val mr = mrDeva.count { low.contains(it) }
            val hi = hiDeva.count { low.contains(it) }
            if (low.contains("मराठी")) return "mr"
            return if (mr > hi) "mr" else "hi"
        }
        val tokens = low.split(Regex("[^a-z]+")).filter { it.isNotEmpty() }.toSet()
        val hi = hiRoman.count { tokens.contains(it) }
        val mr = mrRoman.count { tokens.contains(it) }
        if (hi == 0 && mr == 0) return "en"
        return if (mr > hi) "mr" else "hi"
    }

    class ModelMissing(msg: String) : RuntimeException(msg)

    private fun baseUrl(ctx: Context): String =
        Prefs.get(ctx, Prefs.BASEURL, "https://api.openai.com/v1").ifBlank { "https://api.openai.com/v1" }.trim().trimEnd('/')

    /** Asks the server which models this key may use. */
    private fun listModels(ctx: Context): List<String> {
        return try {
            val req = Request.Builder()
                .url(baseUrl(ctx) + "/models")
                .header("Authorization", "Bearer " + Prefs.get(ctx, Prefs.OPENAI).trim())
                .get().build()
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string() ?: ""
                if (!resp.isSuccessful) return emptyList()
                val arr = JSONObject(text).optJSONArray("data") ?: return emptyList()
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) out.add(arr.getJSONObject(i).optString("id"))
                out
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun pickModel(models: List<String>): String? {
        val prefer = listOf(
            "llama-3.3-70b-versatile", "llama-3.1-8b-instant", "openai/gpt-oss-120b", "openai/gpt-oss-20b",
            "gpt-4o-mini", "gpt-4.1-mini", "gpt-4o"
        )
        for (p in prefer) if (models.contains(p)) return p
        val bad = listOf("whisper", "tts", "guard", "embed", "orpheus", "playai", "safeguard", "moderation", "dall", "image", "transcribe", "audio", "realtime", "vision-preview")
        return models.firstOrNull { m -> bad.none { m.lowercase().contains(it) } }
    }

    fun ask(ctx: Context, userText: String): Reply {
        try {
            return askOnce(ctx, userText)
        } catch (e: ModelMissing) {
            val models = listModels(ctx)
            val pick = pickModel(models)
            if (pick != null && pick != Prefs.get(ctx, Prefs.MODEL)) {
                Prefs.put(ctx, Prefs.MODEL, pick)
                return askOnce(ctx, userText)
            }
            throw RuntimeException(
                (e.message ?: "AI 404") + "\nURL used: " + baseUrl(ctx) + "\nModels this key can use: " +
                    (if (models.isEmpty()) "(none / could not list)" else models.take(25).joinToString(", "))
            )
        }
    }

    private fun askOnce(ctx: Context, userText: String): Reply {
        val key = Prefs.get(ctx, Prefs.OPENAI).trim()
        if (key.isEmpty()) throw IllegalStateException("No OpenAI key")
        var model = Prefs.get(ctx, Prefs.MODEL, "gpt-4o-mini").ifBlank { "gpt-4o-mini" }
        // reasoning models (gpt-oss) are slow and waste tokens: switch Groq users to the fast, accurate Llama model
        if (baseUrl(ctx).contains("groq") && model.startsWith("openai/gpt-oss")) {
            model = "llama-3.3-70b-versatile"
            Prefs.put(ctx, Prefs.MODEL, model)
        }
        val owner = Prefs.get(ctx, Prefs.OWNER, "Aditya").ifBlank { "the user" }

        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", systemPrompt(ctx, owner)))
        history.forEach { msgs.put(it) }
        val userMsg = JSONObject().put("role", "user").put("content", userText + "\n[language detected: " + langHint(userText) + "]")
        msgs.put(userMsg)

        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.4)
            .put("max_tokens", if (Regex("website|web page|webpage|landing|portfolio|ppt|presentation|slides|html|app|game|calculator|tool|quiz|todo|वेबसाइट|प्रेझेंटेशन|प्रेजेंटेशन", RegexOption.IGNORE_CASE).containsMatchIn(userText)) 8000 else 1200)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", msgs)

        val req = Request.Builder()
            .url(baseUrl(ctx) + "/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string() ?: ""
            if (!resp.isSuccessful) {
                val detail = try { JSONObject(text).getJSONObject("error").getString("message") } catch (_: Exception) { text }
                if (resp.code == 404) throw ModelMissing("AI 404: " + detail.take(200))
                throw RuntimeException("AI ${resp.code}: " + detail.take(300))
            }
            val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            val j = JSONObject(content)
            val reply = Reply(
                say = j.optString("say", ""),
                lang = j.optString("lang", "en"),
                actions = j.optJSONArray("actions") ?: JSONArray(),
                end = j.optBoolean("end", false)
            )
            history.add(userMsg)
            history.add(JSONObject().put("role", "assistant").put("content", content))
            while (history.size > 24) history.removeAt(0)
            return reply
        }
    }
}
