package com.aura.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Pro: when Auto-reply is ON, texts back people who SMS you (once per person per hour). */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        if (Prefs.get(c, Prefs.AUTOREPLY) != "on") return
        try {
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
            val from = msgs.firstOrNull()?.originatingAddress ?: return
            val digits = from.filter { it.isDigit() }
            if (digits.length < 10) return                       // skip bank / service senders
            val body = msgs.joinToString("") { it.messageBody ?: "" }.lowercase()
            if (body.contains("auto-reply from jarvis")) return  // never answer ourselves
            val key = "auto_" + digits.takeLast(10)
            val last = Prefs.get(c, key, "0").toLongOrNull() ?: 0L
            if (System.currentTimeMillis() - last < 3_600_000L) return
            Prefs.put(c, key, System.currentTimeMillis().toString())
            Actions(c).autoText(from, Prefs.get(c, Prefs.AUTOMSG, "I'm busy right now. I will reply soon."))
        } catch (_: Exception) {}
    }
}
