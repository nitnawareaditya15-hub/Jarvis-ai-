package com.aura.jarvis

import android.content.Context
import android.graphics.*
import android.os.BatteryManager
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*

/**
 * The Iron-Man style holographic orb: your picture as the HUD backdrop with a live 3D
 * particle sphere, orbit rings and glowing core drawn on top (additive "screen" blending).
 * Modes: NORMAL (orb), DEPLOY (progress + boot log), HUD (full 3D HUD with globe and panels).
 */
class OrbView(ctx: Context) : View(ctx) {

    enum class State { LISTENING, THINKING, SPEAKING }
    enum class Mode { NORMAL, DEPLOY, HUD }

    @Volatile var state = State.LISTENING
    @Volatile var mode = Mode.NORMAL
    @Volatile var level = 0f          // 0..1 voice energy
    @Volatile var caption = ""
    @Volatile var hudTarget = 0f      // 0..1 deploy progress to animate towards
    @Volatile var celebrate = false   // birthday confetti

    private val bmp: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.jarvis_orb)
    private val battery = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val t0 = SystemClock.uptimeMillis()
    private var last = t0
    private var angY = 0f
    private var angX = 0.4f
    private var smooth = 0f
    private var hudProgress = 0f
    private var cosY = 1f; private var sinY = 0f; private var cosX = 1f; private var sinX = 0f

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.ENGLISH)
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
    private var infoAt = 0L
    private var battAt = 0L
    private var timeStr = ""
    private var dateStr = ""
    private var battStr = "PWR --%"

    private val N = 1100
    private val px = FloatArray(N); private val py = FloatArray(N); private val pz = FloatArray(N)
    private val sx = FloatArray(N); private val sy = FloatArray(N); private val sz = FloatArray(N)
    private val far = FloatArray(N * 2); private val mid = FloatArray(N * 2); private val near = FloatArray(N * 2)

    private val GK = 36
    private val globe = FloatArray(11 * GK * 4)

    private val screen = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    private val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { xfermode = null }
    private val dotFar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 110, 0); strokeCap = Paint.Cap.ROUND; xfermode = screen }
    private val dotMid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 160, 20); strokeCap = Paint.Cap.ROUND; xfermode = screen }
    private val dotNear = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 215, 120); strokeCap = Paint.Cap.ROUND; xfermode = screen }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = screen }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(255, 140, 0); xfermode = screen; strokeCap = Paint.Cap.ROUND
    }
    private val title = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 170, 40); typeface = Typeface.create("sans-serif-thin", Typeface.BOLD)
        textAlign = Paint.Align.CENTER; letterSpacing = 0.5f
    }
    private val cap = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 196, 110); typeface = Typeface.MONOSPACE
    }
    private val conf = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = screen }

    private val bootLog = arrayOf(
        "> INIT RENDER CORE", "> LOADING HOLOGRAM MESH", "> CALIBRATING SENSORS",
        "> LINKING NEURAL CORE", "> 3D HUD ONLINE"
    )

    init {
        setBackgroundColor(Color.BLACK)
        setLayerType(LAYER_TYPE_HARDWARE, null)
        val ga = PI * (3 - sqrt(5.0))
        for (i in 0 until N) {
            val y = 1 - 2 * (i + 0.5f) / N
            val r = sqrt(1 - y * y)
            val th = ga * i
            px[i] = (cos(th) * r).toFloat(); py[i] = y; pz[i] = (sin(th) * r).toFloat()
        }
    }

    private fun proj(x: Float, y: Float, z: Float, cx: Float, cy: Float, R: Float, out: FloatArray, o: Int) {
        val x1 = x * cosY + z * sinY
        val z1 = -x * sinY + z * cosY
        val y2 = y * cosX - z1 * sinX
        val z2 = y * sinX + z1 * cosX
        val s = 3.2f / (3.2f - z2)
        out[o] = cx + x1 * R * s
        out[o + 1] = cy + y2 * R * s
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = min(0.05f, (now - last) / 1000f); last = now
        val t = (now - t0) / 1000f
        val w = width.toFloat(); val h = height.toFloat()
        smooth += (level - smooth) * 0.25f
        hudProgress += (hudTarget - hudProgress) * min(1f, dt * 2.5f)
        val m = mode

        if (now - infoAt > 500) {
            infoAt = now
            val d = Date()
            timeStr = timeFmt.format(d); dateStr = dateFmt.format(d).uppercase(Locale.ENGLISH)
        }
        if (now - battAt > 5000) {
            battAt = now
            try {
                battStr = "PWR " + battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + "%"
            } catch (_: Exception) {}
        }

        c.drawColor(Color.BLACK)

        val speed = when (state) {
            State.LISTENING -> 0.55f
            State.THINKING -> 2.4f
            State.SPEAKING -> 0.9f + smooth * 1.8f
        } * (if (m == Mode.DEPLOY) 2.2f else 1f)
        angY += speed * dt
        angX = 0.45f + 0.15f * sin(t * 0.4f)
        cosY = cos(angY); sinY = sin(angY); cosX = cos(angX); sinX = sin(angX)

        val cx = w / 2f; val cy = h * 0.42f
        val pulse = 1f + 0.025f * sin(t * 2.2f) + smooth * 0.10f

        // --- backdrop image (your reference) breathing slowly
        bmp?.let {
            val iw = w * 1.02f * (1f + 0.02f * sin(t * 0.8f)) * (1f + smooth * 0.03f)
            val ih = iw * it.height / it.width
            val dst = RectF(cx - iw / 2, cy - ih / 2, cx + iw / 2, cy + ih / 2)
            imgPaint.alpha = (200 + 55 * sin(t * 1.3f)).toInt().coerceIn(120, 255)
            c.drawBitmap(it, null, dst, imgPaint)
        }

        val R = w * (if (m == Mode.HUD) 0.30f else 0.27f) * pulse

        // --- backlight bloom
        val bloom = R * (2.3f + smooth * 0.8f)
        glow.shader = RadialGradient(cx, cy, bloom,
            intArrayOf(Color.argb(150 + (smooth * 80).toInt().coerceAtMost(100), 255, 120, 10), Color.argb(55, 255, 80, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, bloom, glow)

        // --- wireframe globe (HUD mode)
        if (m == Mode.HUD) drawGlobe(c, cx, cy, R * 1.25f, w)

        // --- 3D particle sphere
        var nf = 0; var nm = 0; var nn = 0
        val fov = 3.2f
        val wob = 1f + 0.06f * sin(t * 3f) + smooth * 0.15f
        for (i in 0 until N) {
            val k = wob + 0.05f * sin(i * 0.37f + t * 2f)
            val x = px[i] * k; val y = py[i] * k; val z = pz[i] * k
            val x1 = x * cosY + z * sinY
            val z1 = -x * sinY + z * cosY
            val y2 = y * cosX - z1 * sinX
            val z2 = y * sinX + z1 * cosX
            val s = fov / (fov - z2)
            val X = cx + x1 * R * s; val Y = cy + y2 * R * s
            sx[i] = X; sy[i] = Y; sz[i] = z2
            when {
                z2 > 0.35f -> { near[nn * 2] = X; near[nn * 2 + 1] = Y; nn++ }
                z2 > -0.35f -> { mid[nm * 2] = X; mid[nm * 2 + 1] = Y; nm++ }
                else -> { far[nf * 2] = X; far[nf * 2 + 1] = Y; nf++ }
            }
        }
        dotFar.strokeWidth = w * 0.0035f; dotMid.strokeWidth = w * 0.0055f; dotNear.strokeWidth = w * 0.0085f
        dotFar.alpha = 120; dotMid.alpha = 190; dotNear.alpha = 255
        c.drawPoints(far, 0, nf * 2, dotFar)
        c.drawPoints(mid, 0, nm * 2, dotMid)
        c.drawPoints(near, 0, nn * 2, dotNear)

        // --- electric filaments linking nearby front points
        ring.strokeWidth = w * 0.0016f; ring.alpha = 90
        var j = 0
        var drawn = 0
        while (j < N - 7 && drawn < 70) {
            val a = (j * 13 + (t * 8).toInt() * 7) % N
            val b = (a + 5 + (j % 11)) % N
            if (sz[a] > 0f && sz[b] > 0f) { c.drawLine(sx[a], sy[a], sx[b], sy[b], ring); drawn++ }
            j += 3
        }

        // --- orbit rings (3 tilted ellipses)
        for (r in 0 until 3) {
            val tilt = r * 60f + t * (8f + 6f * r) * if (state == State.THINKING || m == Mode.DEPLOY) 3f else 1f
            c.save()
            c.rotate(tilt, cx, cy)
            ring.alpha = 150 - r * 30
            ring.strokeWidth = w * (0.004f - r * 0.001f)
            val rx = R * (1.55f + r * 0.18f); val ry = rx * (0.28f + 0.05f * r)
            val oval = RectF(cx - rx, cy - ry, cx + rx, cy + ry)
            val sweep = 200f + 60f * sin(t + r)
            c.drawArc(oval, t * (40f + r * 25f), sweep, false, ring)
            c.restore()
        }
        // HUD circle segments
        ring.alpha = 200; ring.strokeWidth = w * 0.006f
        val hr = R * 1.95f
        val hudRect = RectF(cx - hr, cy - hr, cx + hr, cy + hr)
        for (s in 0 until 6) c.drawArc(hudRect, -t * 30f + s * 60f, 34f, false, ring)
        ring.strokeWidth = w * 0.002f; ring.alpha = 120
        val hr2 = R * 2.15f
        c.drawArc(RectF(cx - hr2, cy - hr2, cx + hr2, cy + hr2), t * 55f, 250f, false, ring)

        // --- hot core
        val core = R * (0.28f + smooth * 0.22f) * (1f + 0.08f * sin(t * 6f))
        glow.shader = RadialGradient(cx, cy, core * 2.6f,
            intArrayOf(Color.argb(255, 255, 250, 220), Color.argb(230, 255, 190, 60), Color.argb(90, 255, 100, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 0.25f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, core * 2.6f, glow)

        // --- voice-reactive rim bars
        ring.strokeWidth = w * 0.004f
        val bars = 60
        for (b in 0 until bars) {
            val a = b * 2 * PI / bars + t * 0.3
            val mm = (0.35f + 0.65f * abs(sin(b * 0.9f + t * 5f))) * (0.15f + smooth)
            val r0 = R * 2.3f; val r1 = r0 + R * 0.35f * mm
            ring.alpha = (80 + 150 * mm).toInt().coerceAtMost(255)
            c.drawLine(cx + cos(a).toFloat() * r0, cy + sin(a).toFloat() * r0, cx + cos(a).toFloat() * r1, cy + sin(a).toFloat() * r1, ring)
        }

        // --- deploy progress ring + boot log
        if (m == Mode.DEPLOY || m == Mode.HUD) drawDeploy(c, w, h, cx, cy, R, m)
        if (m == Mode.HUD) drawPanels(c, w, h, t)

        // --- scanline + corner brackets + live readouts
        drawChrome(c, w, h, t)

        // --- text
        title.textSize = w * 0.06f
        c.drawText("J.A.R.V.I.S", cx, h * 0.075f, title)
        title.textSize = w * 0.032f; title.alpha = 200
        c.drawText(when (m) {
            Mode.DEPLOY -> "DEPLOYING 3D HUD"
            Mode.HUD -> "3D HUD ACTIVE"
            else -> when (state) {
                State.LISTENING -> "LISTENING"
                State.THINKING -> "PROCESSING"
                State.SPEAKING -> "PRO  ONLINE"
            }
        }, cx, h * 0.105f, title)
        title.alpha = 255

        if (caption.isNotBlank()) {
            cap.textAlign = Paint.Align.LEFT
            cap.textSize = if (caption.length > 90) w * 0.034f else w * 0.045f
            val layout = StaticLayout.Builder.obtain(caption, 0, caption.length, cap, (w * 0.84f).toInt())
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(7).setEllipsize(android.text.TextUtils.TruncateAt.END).build()
            c.save(); c.translate(w * 0.08f, h * 0.755f); layout.draw(c); c.restore()
        }

        if (celebrate) drawConfetti(c, w, h, t)

        postInvalidateOnAnimation()
    }

    private fun drawGlobe(c: Canvas, cx: Float, cy: Float, R: Float, w: Float) {
        var o = 0
        val a = FloatArray(2); val b = FloatArray(2)
        for (curve in 0 until 11) {
            for (s in 0 until GK) {
                val t1 = (s * 2 * PI / GK).toFloat(); val t2 = ((s + 1) * 2 * PI / GK).toFloat()
                val x1: Float; val y1: Float; val z1: Float; val x2: Float; val y2: Float; val z2: Float
                if (curve < 6) {
                    val phi = (curve * PI / 6).toFloat()
                    x1 = cos(t1) * cos(phi); y1 = sin(t1); z1 = cos(t1) * sin(phi)
                    x2 = cos(t2) * cos(phi); y2 = sin(t2); z2 = cos(t2) * sin(phi)
                } else {
                    val lat = ((curve - 8) * 0.32f)
                    val yy = sin(lat); val rr = cos(lat)
                    x1 = rr * cos(t1); y1 = yy; z1 = rr * sin(t1)
                    x2 = rr * cos(t2); y2 = yy; z2 = rr * sin(t2)
                }
                proj(x1, y1, z1, cx, cy, R, a, 0)
                proj(x2, y2, z2, cx, cy, R, b, 0)
                globe[o++] = a[0]; globe[o++] = a[1]; globe[o++] = b[0]; globe[o++] = b[1]
            }
        }
        ring.strokeWidth = w * 0.0018f; ring.alpha = 95
        c.drawLines(globe, 0, o, ring)
    }

    private fun drawDeploy(c: Canvas, w: Float, h: Float, cx: Float, cy: Float, R: Float, m: Mode) {
        val p = if (m == Mode.HUD) 1f else hudProgress.coerceIn(0f, 1f)
        val pr = R * 2.55f
        val rect = RectF(cx - pr, cy - pr, cx + pr, cy + pr)
        ring.strokeWidth = w * 0.012f; ring.alpha = 55
        c.drawArc(rect, 0f, 360f, false, ring)
        ring.strokeWidth = w * 0.012f; ring.alpha = 255
        c.drawArc(rect, -90f, 360f * p, false, ring)
        if (m == Mode.DEPLOY) {
            title.textSize = w * 0.085f
            c.drawText((p * 100).toInt().toString() + "%", cx, cy + pr + w * 0.13f, title)
        }
        cap.textAlign = Paint.Align.LEFT
        cap.textSize = w * 0.03f
        val shown = if (m == Mode.HUD) bootLog.size else min(bootLog.size, (p * 5.2f).toInt() + 1)
        for (i in 0 until shown) {
            cap.alpha = if (i == shown - 1 && m == Mode.DEPLOY) 255 else 150
            val done = i < shown - 1 || p >= 0.999f
            c.drawText(bootLog[i] + (if (done) "  [OK]" else " ..."), w * 0.06f, h * 0.905f + i * w * 0.036f - (if (m == Mode.HUD) w * 0.0f else 0f), cap)
        }
        cap.alpha = 255
    }

    private fun drawPanels(c: Canvas, w: Float, h: Float, t: Float) {
        val labels = arrayOf("CORE", "NEURAL", "POWER", "SENSOR", "NET")
        cap.textAlign = Paint.Align.LEFT
        cap.textSize = w * 0.026f
        for (i in labels.indices) {
            val y = h * 0.50f + i * h * 0.04f
            val v = 0.35f + 0.65f * abs(sin(t * (0.9f + i * 0.23f) + i))
            cap.alpha = 220
            c.drawText(labels[i], w * 0.04f, y, cap)
            ring.strokeWidth = w * 0.006f
            ring.alpha = 70
            c.drawLine(w * 0.04f, y + w * 0.014f, w * 0.20f, y + w * 0.014f, ring)
            ring.alpha = 235
            c.drawLine(w * 0.04f, y + w * 0.014f, w * 0.04f + w * 0.16f * v, y + w * 0.014f, ring)
        }
        cap.alpha = 255
        // right equalizer
        ring.strokeWidth = w * 0.012f
        for (i in 0 until 8) {
            val v = 0.25f + 0.75f * abs(sin(t * (1.6f + i * 0.37f) + i * 1.3f))
            val x = w * 0.80f + i * w * 0.022f
            val base = h * 0.66f
            ring.alpha = 230
            c.drawLine(x, base, x, base - h * 0.12f * v, ring)
        }
    }

    private fun drawChrome(c: Canvas, w: Float, h: Float, t: Float) {
        // scanline sweep
        val y = ((t * 0.3f) % 1f) * h
        ring.strokeWidth = w * 0.003f
        ring.alpha = 70; c.drawLine(0f, y, w, y, ring)
        ring.alpha = 35; c.drawLine(0f, y - h * 0.008f, w, y - h * 0.008f, ring)
        ring.alpha = 15; c.drawLine(0f, y - h * 0.016f, w, y - h * 0.016f, ring)
        // corner brackets
        val mx = w * 0.04f; val my = h * 0.035f; val len = w * 0.09f
        ring.strokeWidth = w * 0.005f; ring.alpha = 210
        c.drawLine(mx, my, mx + len, my, ring); c.drawLine(mx, my, mx, my + len, ring)
        c.drawLine(w - mx, my, w - mx - len, my, ring); c.drawLine(w - mx, my, w - mx, my + len, ring)
        c.drawLine(mx, h - my, mx + len, h - my, ring); c.drawLine(mx, h - my, mx, h - my - len, ring)
        c.drawLine(w - mx, h - my, w - mx - len, h - my, ring); c.drawLine(w - mx, h - my, w - mx, h - my - len, ring)
        // readouts
        cap.textSize = w * 0.028f; cap.alpha = 200
        cap.textAlign = Paint.Align.LEFT
        c.drawText(timeStr, w * 0.07f, h * 0.15f, cap)
        c.drawText(dateStr, w * 0.07f, h * 0.15f + w * 0.04f, cap)
        cap.textAlign = Paint.Align.RIGHT
        c.drawText(battStr, w * 0.93f, h * 0.15f, cap)
        c.drawText("PRO ACTIVE", w * 0.93f, h * 0.15f + w * 0.04f, cap)
        cap.textAlign = Paint.Align.LEFT
        cap.alpha = 255
    }

    private fun drawConfetti(c: Canvas, w: Float, h: Float, t: Float) {
        for (i in 0 until 70) {
            val fx = ((i * 73) % 100) / 100f
            val x = fx * w + sin(t * 1.5f + i) * w * 0.03f
            val y = ((t * (120f + (i % 7) * 25f) + i * 53f) % (h + 60f)) - 30f
            conf.color = when (i % 4) {
                0 -> Color.rgb(255, 140, 0)
                1 -> Color.rgb(255, 215, 120)
                2 -> Color.rgb(255, 255, 255)
                else -> Color.rgb(255, 90, 30)
            }
            c.drawCircle(x, y, w * (0.006f + (i % 3) * 0.003f), conf)
        }
    }
}
