package com.aura.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Jarvis's "hands": scrolls, taps and presses buttons anywhere on the phone. */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun screenW() = resources.displayMetrics.widthPixels.toFloat()
    private fun screenH() = resources.displayMetrics.heightPixels.toFloat()

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 350) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        dispatchGesture(g, null, null)
    }

    /** dir = where the user wants to go, so "down" drags the finger upwards. */
    fun scroll(dir: String) {
        val w = screenW(); val h = screenH()
        when (dir.lowercase()) {
            "down" -> swipe(w * 0.5f, h * 0.72f, w * 0.5f, h * 0.28f)
            "up" -> swipe(w * 0.5f, h * 0.28f, w * 0.5f, h * 0.72f)
            "right" -> swipe(w * 0.85f, h * 0.5f, w * 0.15f, h * 0.5f)
            "left" -> swipe(w * 0.15f, h * 0.5f, w * 0.85f, h * 0.5f)
        }
    }

    fun tapFraction(xf: Float, yf: Float) {
        val p = Path().apply { moveTo(screenW() * xf, screenH() * yf) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    private fun clickableAncestor(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var cur = n
        var guard = 0
        while (cur != null && guard++ < 8) {
            if (cur.isClickable) return cur
            cur = cur.parent
        }
        return null
    }

    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (n in nodes) {
            val target = clickableAncestor(n)
            if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        // fall back to tapping the centre of the first match
        val first = nodes.firstOrNull() ?: return false
        val r = android.graphics.Rect()
        first.getBoundsInScreen(r)
        val p = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null
        )
        return true
    }

    private fun findPlayNode(n: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        val d = n.contentDescription?.toString()?.lowercase() ?: ""
        if (d.contains("play video") || (d.contains(" - ") && d.contains("seconds") && n.isClickable)) return n
        for (i in 0 until n.childCount) {
            findPlayNode(n.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    /** On YouTube search results: press the first real video. Falls back to a tap where the first result usually is. */
    fun playFirstVideo(fallbackTap: Boolean = false): Boolean {
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString() ?: ""
        if (root != null && pkg.contains("youtube")) {
            val node = findPlayNode(root)
            if (node != null) {
                val t = clickableAncestor(node) ?: node
                if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                val r = android.graphics.Rect(); node.getBoundsInScreen(r)
                if (r.width() > 0) {
                    tapFraction(r.exactCenterX() / screenW(), r.exactCenterY() / screenH()); return true
                }
            }
            // already watching a video? then do nothing
            val inWatch = root.findAccessibilityNodeInfosByText("Minimize").isNotEmpty() ||
                root.findAccessibilityNodeInfosByText("Subscribe").isNotEmpty()
            if (inWatch) return true
        }
        if (fallbackTap && pkg.contains("youtube")) tapFraction(0.5f, 0.33f)
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Flips the first switch on the open Settings page to the wanted state (null = just toggle it). */
    fun setSwitch(desired: Boolean?): Boolean {
        for (root in allRoots()) {
            val sw = findSwitch(root) ?: continue
            if (desired != null && sw.isChecked == desired) return true
            val t = if (sw.isClickable) sw else (clickableAncestor(sw) ?: sw)
            return t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        return false
    }

    private fun findByLabel(n: AccessibilityNodeInfo?, names: List<String>, depth: Int = 0): AccessibilityNodeInfo? {
        if (n == null || depth > 30) return null
        val t = (n.text?.toString() ?: "").lowercase()
        val d = (n.contentDescription?.toString() ?: "").lowercase()
        for (nm in names) {
            val k = nm.lowercase()
            if ((t.isNotEmpty() && t.contains(k)) || (d.isNotEmpty() && d.contains(k))) return n
        }
        for (i in 0 until n.childCount) findByLabel(n.getChild(i), names, depth + 1)?.let { return it }
        return null
    }

    /** Presses the loudspeaker button on the in-call screen (if it is not already on). */
    fun pressSpeaker(): Boolean {
        val names = listOf("speaker", "loudspeaker", "speakerphone", "hands-free", "handsfree")
        for (root in allRoots()) {
            val n = findByLabel(root, names) ?: continue
            if (n.isChecked || n.isSelected) return true
            val t = clickableAncestor(n) ?: n
            return t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        return false
    }

    /** Opens the quick-settings panel and presses the tile whose label contains one of the names. */
    fun clickTile(names: List<String>, done: (Boolean) -> Unit) {
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        var tries = 0
        lateinit var step: Runnable
        step = Runnable {
            var hit: AccessibilityNodeInfo? = null
            for (r in allRoots()) { hit = findByLabel(r, names); if (hit != null) break }
            if (hit != null) {
                val t = clickableAncestor(hit) ?: hit
                done(t.performAction(AccessibilityNodeInfo.ACTION_CLICK))
            } else if (tries++ < 3) {
                if (tries == 2) swipe(screenW() * 0.5f, screenH() * 0.35f, screenW() * 0.5f, screenH() * 0.75f, 300) // expand panel
                h.postDelayed(step, 700)
            } else done(false)
        }
        h.postDelayed(step, 900)
    }

    private fun collectText(n: AccessibilityNodeInfo?, out: LinkedHashSet<String>, depth: Int = 0) {
        if (n == null || depth > 40 || out.size > 400) return
        if (n.isVisibleToUser) {
            val t = n.text?.toString()?.trim() ?: ""
            val d = n.contentDescription?.toString()?.trim() ?: ""
            if (t.isNotEmpty()) out.add(t) else if (d.isNotEmpty()) out.add(d)
        }
        for (i in 0 until n.childCount) collectText(n.getChild(i), out, depth + 1)
    }

    /** Everything written on the screen right now (all apps except Jarvis itself and the status bar). */
    fun readScreen(): String {
        val out = LinkedHashSet<String>()
        for (root in allRoots()) {
            val pkg = root.packageName?.toString() ?: ""
            if (pkg == packageName || pkg == "com.android.systemui") continue
            collectText(root, out)
        }
        val sb = StringBuilder()
        for (s in out) { if (sb.length > 6000) break; sb.append(s).append('\n') }
        return sb.toString().trim()
    }

    /** Presses WhatsApp's green Send button (message screen or the share preview). */
    fun clickSend(): Boolean {
        for (root in allRoots()) {
            val pkg = root.packageName?.toString() ?: ""
            if (!pkg.startsWith("com.whatsapp")) continue
            val byId = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send")
            for (n in byId) {
                val t = clickableAncestor(n) ?: n
                if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            val byLabel = findByLabel(root, listOf("send"))
            if (byLabel != null) {
                val t = clickableAncestor(byLabel) ?: byLabel
                if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
        }
        return false
    }

    fun lockScreen(): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false

    private fun allRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try { for (w in windows) w.root?.let { out.add(it) } } catch (_: Exception) {}
        rootInActiveWindow?.let { out.add(it) }
        return out
    }

    private fun pressKey(label: String, ids: List<String>): Boolean {
        for (root in allRoots()) {
            var node: AccessibilityNodeInfo? = null
            for (id in ids) {
                val l = root.findAccessibilityNodeInfosByViewId(id)
                if (!l.isNullOrEmpty()) { node = l[0]; break }
            }
            if (node == null) {
                node = root.findAccessibilityNodeInfosByText(label).firstOrNull { n ->
                    n.text?.toString() == label || n.contentDescription?.toString() == label
                }
            }
            if (node != null) {
                val t = clickableAncestor(node) ?: node
                if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                val r = android.graphics.Rect(); node.getBoundsInScreen(r)
                if (r.width() > 0) { tapFraction(r.exactCenterX() / screenW(), r.exactCenterY() / screenH()); return true }
            }
        }
        return false
    }

    /** Wakes the lock screen, types the PIN on the keypad and presses enter. The PIN is never stored. */
    fun unlockWithPin(pin: String, done: (Boolean) -> Unit) {
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        fun swipeUp() = swipe(screenW() * 0.5f, screenH() * 0.88f, screenW() * 0.5f, screenH() * 0.25f, 300)
        swipeUp()
        var idx = 0
        var tries = 0
        lateinit var step: Runnable
        step = Runnable {
            if (idx >= pin.length) {
                h.postDelayed({
                    val ok = pressKey("Enter", listOf("com.android.systemui:id/key_enter")) ||
                        pressKey("OK", emptyList())
                    done(true)
                }, 350)
                return@Runnable
            }
            val d = pin[idx].toString()
            if (pressKey(d, listOf("com.android.systemui:id/key$d"))) {
                idx++; tries = 0
                h.postDelayed(step, 320)
            } else if (tries++ < 5) {
                if (tries == 2 && idx == 0) swipeUp()
                h.postDelayed(step, 600)
            } else done(false)
        }
        h.postDelayed(step, 1100)
    }

    fun global(action: String) {
        when (action) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "screenshot" -> if (android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    /** Android blocks apps from flipping the hotspot directly, so we open the page and press the switch. */
    fun flipHotspotSwitch(): Boolean {
        val root = rootInActiveWindow ?: return false
        val labels = listOf("hotspot", "Hotspot", "Personal Hotspot", "Portable hotspot", "tethering")
        for (l in labels) {
            for (n in root.findAccessibilityNodeInfosByText(l)) {
                // look for a switch inside the same row
                var row: AccessibilityNodeInfo? = n
                var guard = 0
                while (row != null && guard++ < 6) {
                    val sw = findSwitch(row)
                    if (sw != null && sw.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    row = row.parent
                }
                clickableAncestor(n)?.let { if (it.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true }
            }
        }
        return findSwitch(root)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun findSwitch(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val cn = n.className?.toString() ?: ""
        if (cn.contains("Switch") || cn.contains("ToggleButton") || cn.contains("CompoundButton")) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findSwitch(c)?.let { return it }
        }
        return null
    }
}
