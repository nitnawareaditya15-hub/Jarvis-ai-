JARVIS - build & setup (phone only, no computer)

A. GET THE APK (GitHub builds it for you, free)
1. Make a free account at github.com (browser on your phone, "Desktop site" ON helps).
2. New repository -> name: jarvis -> Private -> Create.
3. "uploading an existing file" -> upload Jarvis.zip (do NOT unzip) -> Commit.
4. Add file -> Create new file -> name it exactly:  .github/workflows/build.yml
   Paste the contents of build.yml (sent separately) -> Commit.
5. Open the "Actions" tab -> wait ~5-8 minutes for the green tick.
   (If it did not start: Actions -> Build Jarvis APK -> Run workflow.)
6. Open "Releases" (right side of repo page) -> download Jarvis.apk -> install
   (allow "install unknown apps" for your browser if asked).

B. KEYS (both free/cheap)
- OpenAI key: platform.openai.com -> API keys (needs a few $ credit).
- No wake-word key needed any more.

C. SET UP IN THE APP (top to bottom)
Paste both keys -> Save -> tap each permission button -> in Accessibility turn ON "Jarvis Hands"
-> allow background battery -> START JARVIS. Then close the app and say "Jarvis" / "Hey Jarvis".

D. VIVO V25: Settings -> Battery -> Background power consumption -> Jarvis -> Allow;
   Settings -> Apps -> Autostart -> Jarvis ON; lock Jarvis in the recents screen.

Try: "Hey Jarvis, torch on" / "scroll down" / "open WhatsApp" / "call Mom" / "alarm at 6:30" /
"timer 5 minutes" / "Play Store mein PUBG search karo" / "hotspot on kar" / "tap on Search".

PPT: "Hey Jarvis, make a presentation on solar energy" -> saved in Downloads/Jarvis and opened (needs WPS Office / PowerPoint / Google Slides installed).

NEW (Nov 2):
- Incoming call: Jarvis announces who is calling and asks; say "pick up" / "cut it". Speaker on request.
- "Hey Jarvis, call my best friend": fill "My people" in the app (best friend = Aradhya Patil) or say "remember Aradhya Patil is my best friend".
- Birthday: type it in the app (DD-MM-YYYY). Jarvis wishes you after 7 am on the day.
- "Hey Jarvis, deploy 3D HUD": narrates every step, then asks "Shall I open it?" -> yes opens the full 3D HUD.
- Orb is fully black/opaque over any screen (home screen too); tap it to dismiss.

FREE BRAIN (no money): console.groq.com -> sign in with Google -> API Keys -> Create (key starts gsk_).
In the app tap "Use FREE Groq", paste the key in the first box, Save everything.

NEW (Nov 5):
- Wake word now runs OFFLINE (Vosk). First START downloads a ~40 MB model once (needs internet), then Reels/YouTube/music no longer stutter.
- "Hey Jarvis, make a website for ..." -> builds it, saves to Downloads/Jarvis and opens it full screen.
- "Open YouTube and search Marvel Doomsday trailer and play it" -> searches and plays the first result (needs Accessibility ON).

NEW (Nov 6):
- "Hey Jarvis, lock my phone" -> locks the screen (needs Accessibility ON, Android 9+).
- Phone locked: "Hey Jarvis, unlock my phone" -> Jarvis asks for the PIN, you say the digits, it types them on the lock screen. PIN is never saved or sent to the AI.

NEW (Nov 6, part 2):
- "Hey Jarvis, airplane mode on / bluetooth off / auto-rotate on / wifi / mobile data / do not disturb / volume / brightness".
  Auto-rotate + brightness need the app button "Allow Modify system settings". Others need Accessibility ON.
- Jarvis steps aside automatically when another app uses the microphone (calls, voice chat, recording) and comes back after.
- Replies in the language you speak (English / Hindi / Marathi), decided fresh each time.
- App has 6 voices (4 male, 2 female) + "Hear this voice" button.
- Countdown widget: button in the app, or say "Hey Jarvis, add a countdown widget for my birthday".

NEW (Nov 7):
- Incoming call: Jarvis stays silent. Say "Hey Jarvis, pick up the call" (or "reject / cut the call") and it does it.
- Wake-engine download now resumes if the connection drops.

NEW (Nov 7, calls):
- Ringing: "Hey Jarvis, pick up the call and say I am busy, call after 3" -> answers on speaker, tells the caller clearly (twice), hangs up.
- "Hey Jarvis, pick up the call" -> just answers. "Hey Jarvis, reject the call" -> rejects. No announcements.

NEW (Nov 8):
- Call message: loudspeaker pressed on the call screen, alarm-type loud slow voice, said twice (caller hears it through the phone mic).
- English mode: listening + orb text are English (Reply language = English).

NEW (Nov 8, fix):
- Ringing + "pick up and tell her I'm busy..." : the brain writes the message (safe default if no internet), call is answered and the message is spoken twice on the loudspeaker.
- Wake word now needs a clean "(Hey) Jarvis" at the start of a sentence, so TV/talking no longer wakes it by mistake.

NEW (Nov 8, calls part 3):
- Phones cancel their own speaker sound out of a call, so callers can't hear Jarvis. Jarvis now TEXTS the caller your message
  (and (mode "text") rejects the call). Setting in the app: "When I say pick up the call and tell them...".
  Needs the SMS permission (tap the permission button again). Normal SMS charges may apply.

NEW: MESSAGES + SCREEN READING
- "Hey Jarvis, text Mom that I'm in a meeting, I'll call at 4"  -> SMS (needs SMS permission)
- "Hey Jarvis, WhatsApp Aradhya that I'll be late"              -> WhatsApp text (needs Jarvis Hands accessibility ON)
- "Hey Jarvis, send Mom a voice message saying ..."             -> Jarvis voice clip sent on WhatsApp (needs Jarvis Hands ON; may need a fix round)
- "Hey Jarvis, read my screen" / "what is on my screen" / "summarize this page"  -> Jarvis reads the text on screen (needs Jarvis Hands ON; text only, not pictures)

JARVIS PRO (everything above plus)
- Faster replies (short answers are capped), longer memory in a chat, battery-aware "good morning" briefing
- "Hey Jarvis, pause / next song / previous song"; "take a screenshot"; "open Wi-Fi / Bluetooth / display / battery settings"; "mute my mic"
- "Hey Jarvis, read my notifications" (needs Jarvis Hands ON)
- "Hey Jarvis, turn on auto reply, say I'm in class" -> texts back missed callers and people who SMS you (once per hour each). "Turn off auto reply" to stop. (Tap the permission button again so SMS-receive is allowed.)
- "Hey Jarvis, who called me?" / "any missed calls?" / "call back the last missed call"
- HUD shows PRO; app name is Jarvis Pro (installs over the old app)
