JARVIS - build & setup (phone only, no computer)

A. GET THE APK (GitHub builds it for you, free)
1. Make a free account at github.com (browser on your phone, "Desktop site" ON helps).
2. New repository -> name: jarvis -> Private -> Create.
3. "uploading an existing file" -> upload Jarvis.zip (do NOT unzip) -> Commit.
4. Add file -> Create new file -> name it exactly:  .github/workflows/build.yml
   Paste the contents of build.yml (sent separately) -> Commit.
5. Open the "Actions" tab -> wait ~5-8 minutes for the green tick.
   (If it did not start: Actions -> Build Jarvis APK -> Run workflow.)
6. Open "Releases" (right side of repo page) -> download Jarvis.apk -> install
   (allow "install unknown apps" for your browser if asked).

B. KEYS (both free/cheap)
- OpenAI key: platform.openai.com -> API keys (needs a few $ credit).
- Picovoice key: console.picovoice.ai -> sign up -> copy AccessKey (free).

C. SET UP IN THE APP (top to bottom)
Paste both keys -> Save -> tap each permission button -> in Accessibility turn ON "Jarvis Hands"
-> allow background battery -> START JARVIS. Then close the app and say "Jarvis" / "Hey Jarvis".

D. VIVO V25: Settings -> Battery -> Background power consumption -> Jarvis -> Allow;
   Settings -> Apps -> Autostart -> Jarvis ON; lock Jarvis in the recents screen.

Try: "Hey Jarvis, torch on" / "scroll down" / "open WhatsApp" / "call Mom" / "alarm at 6:30" /
"timer 5 minutes" / "Play Store mein PUBG search karo" / "hotspot on kar" / "tap on Search".
