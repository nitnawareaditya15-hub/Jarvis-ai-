package com.aura.jarvis

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

/** Home-screen widget: days left until your birthday (or any date Jarvis was told). */
class CountdownWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(context))
    }

    companion object {
        fun daysUntil(d: Int, m: Int): Int {
            val today = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val next = (today.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.MONTH, m - 1)
                set(Calendar.DAY_OF_MONTH, minOf(d, getActualMaximum(Calendar.DAY_OF_MONTH)))
            }
            if (next.before(today)) {
                next.add(Calendar.YEAR, 1)
            }
            return ((next.timeInMillis - today.timeInMillis) / 86_400_000L).toInt()
        }

        fun build(c: Context): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget_countdown)
            val custom = Prefs.parseDate(Prefs.get(c, Prefs.WDATE))
            val date = custom ?: Prefs.birthday(c)
            val label = Prefs.get(c, Prefs.WLABEL).ifBlank { if (custom == null) "BIRTHDAY" else "COUNTDOWN" }.uppercase()
            if (date == null) {
                v.setTextViewText(R.id.w_label, "J.A.R.V.I.S")
                v.setTextViewText(R.id.w_days, "--")
                v.setTextViewText(R.id.w_sub, "set your birthday in the app")
            } else {
                val days = daysUntil(date[0], date[1])
                v.setTextViewText(R.id.w_label, label)
                if (days == 0) {
                    v.setTextViewText(R.id.w_days, "TODAY")
                    v.setTextViewText(R.id.w_sub, "Happy celebration!")
                } else {
                    v.setTextViewText(R.id.w_days, days.toString())
                    v.setTextViewText(R.id.w_sub, if (days == 1) "day to go" else "days to go")
                }
            }
            val open = PendingIntent.getActivity(c, 7, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.w_root, open)
            return v
        }

        fun refresh(c: Context) {
            val mgr = AppWidgetManager.getInstance(c)
            val ids = mgr.getAppWidgetIds(ComponentName(c, CountdownWidget::class.java))
            for (id in ids) mgr.updateAppWidget(id, build(c))
        }

        /** Asks the home screen to add the widget (a small confirm box appears). Returns false if the launcher can't. */
        fun requestPin(c: Context): Boolean {
            val mgr = AppWidgetManager.getInstance(c)
            return try {
                if (mgr.isRequestPinAppWidgetSupported) {
                    mgr.requestPinAppWidget(ComponentName(c, CountdownWidget::class.java), null, null)
                } else false
            } catch (_: Exception) { false }
        }
    }
}
