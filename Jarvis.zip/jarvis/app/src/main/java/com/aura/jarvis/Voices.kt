package com.aura.jarvis

import android.content.Context
import java.util.Locale

/** Six voice styles: 4 male + 2 female. Each changes pitch, speed and accent (and picks a matching engine voice when it can). */
object Voices {
    data class P(val name: String, val pitch: Float, val rate: Float, val accent: String, val male: Boolean)

    val list = listOf(
        P("Male 1 - Jarvis (deep British)", 0.78f, 0.95f, "UK", true),
        P("Male 2 - Classic (Indian)", 0.88f, 0.97f, "IN", true),
        P("Male 3 - Commander (American)", 0.82f, 1.05f, "US", true),
        P("Male 4 - Butler (calm British)", 0.95f, 0.92f, "UK", true),
        P("Female 1 - Friday (British)", 1.12f, 1.0f, "UK", false),
        P("Female 2 - Aura (Indian)", 1.22f, 1.02f, "IN", false)
    )

    fun index(c: Context): Int = (Prefs.get(c, Prefs.VOICE, "0").toIntOrNull() ?: 0).coerceIn(0, list.size - 1)
    fun profile(c: Context): P = list[index(c)]

    fun accentLocale(a: String): Locale = when (a) {
        "UK" -> Locale.UK
        "US" -> Locale.US
        else -> Locale("en", "IN")
    }

    // Google voice codes that usually sound male / female (best effort; the exact-voice picker overrides this)
    val maleCodes = listOf("x-gbb", "x-gbd", "x-rjs", "x-iom", "x-iol", "x-tpd", "x-end", "x-ind", "x-iob")
    val femaleCodes = listOf("x-gba", "x-gbc", "x-gbg", "x-sfg", "x-iog", "x-tpc", "x-tpf", "x-ene", "x-ahp", "x-inc")
}
