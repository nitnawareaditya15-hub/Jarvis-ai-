package com.aura.jarvis

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun get(c: Context, key: String, def: String = ""): String = sp(c).getString(key, def) ?: def
    fun put(c: Context, key: String, value: String) = sp(c).edit().putString(key, value).apply()

    const val OPENAI = "openai"
    const val BASEURL = "baseurl"
    const val PICOVOICE = "picovoice"
    const val MODEL = "model"
    const val OWNER = "owner"
    const val LANG = "lang" // speech recognition locale: hi-IN, en-IN, mr-IN
    const val BIRTHDAY = "birthday"
    const val PEOPLE = "people"
    const val FACTS = "facts"
    const val WISHED = "wished"
    const val REPLY = "reply"          // auto | en | hi | mr  (language Jarvis answers in)
    const val VOICE = "voice"          // voice profile index 0..5
    const val VOICEX = "voicex"        // optional exact engine voice name
    const val VOICELIST = "voicelist"  // voices found by the phone's speech engine (written by the service)
    const val WLABEL = "wlabel"        // countdown widget label
    const val WDATE = "wdate"          // countdown widget target date DD-MM[-YYYY]; empty = birthday

    /** [day, month, year-or-0] or null when not set / not valid. */
    fun birthday(c: Context): IntArray? {
        val s = get(c, BIRTHDAY).trim()
        if (s.isEmpty()) return null
        val p = s.split("-", "/", ".", " ").filter { it.isNotBlank() }
        val d = p.getOrNull(0)?.toIntOrNull() ?: return null
        val m = p.getOrNull(1)?.toIntOrNull() ?: return null
        val y = p.getOrNull(2)?.toIntOrNull() ?: 0
        if (d !in 1..31 || m !in 1..12) return null
        return intArrayOf(d, m, y)
    }

    /** Parses "DD-MM[-YYYY]" to [day, month, year-or-0]. */
    fun parseDate(s: String): IntArray? {
        val p = s.trim().split("-", "/", ".", " ").filter { it.isNotBlank() }
        val d = p.getOrNull(0)?.toIntOrNull() ?: return null
        val m = p.getOrNull(1)?.toIntOrNull() ?: return null
        val y = p.getOrNull(2)?.toIntOrNull() ?: 0
        if (d !in 1..31 || m !in 1..12) return null
        return intArrayOf(d, m, y)
    }
}
