package com.aura.jarvis

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun get(c: Context, key: String, def: String = ""): String = sp(c).getString(key, def) ?: def
    fun put(c: Context, key: String, value: String) = sp(c).edit().putString(key, value).apply()

    const val OPENAI = "openai"
    const val PICOVOICE = "picovoice"
    const val MODEL = "model"
    const val OWNER = "owner"
    const val LANG = "lang" // speech recognition locale: hi-IN, en-IN, mr-IN
}
