package com.aura.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Jarvis's "hands": scrolls, taps and presses buttons anywhere on the phone. */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun screenW() = resources.displayMetrics.widthPixels.toFloat()
    private fun screenH() = resources.displayMetrics.heightPixels.toFloat()

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 350) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        dispatchGesture(g, null, null)
    }

    /** dir = where the user wants to go, so "down" drags the finger upwards. */
    fun scroll(dir: String) {
        val w = screenW(); val h = screenH()
        when (dir.lowercase()) {
            "down" -> swipe(w * 0.5f, h * 0.72f, w * 0.5f, h * 0.28f)
            "up" -> swipe(w * 0.5f, h * 0.28f, w * 0.5f, h * 0.72f)
            "right" -> swipe(w * 0.85f, h * 0.5f, w * 0.15f, h * 0.5f)
            "left" -> swipe(w * 0.15f, h * 0.5f, w * 0.85f, h * 0.5f)
        }
    }

    fun tapFraction(xf: Float, yf: Float) {
        val p = Path().apply { moveTo(screenW() * xf, screenH() * yf) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    private fun clickableAncestor(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var cur = n
        var guard = 0
        while (cur != null && guard++ < 8) {
            if (cur.isClickable) return cur
            cur = cur.parent
        }
        return null
    }

    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (n in nodes) {
            val target = clickableAncestor(n)
            if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        // fall back to tapping the centre of the first match
        val first = nodes.firstOrNull() ?: return false
        val r = android.graphics.Rect()
        first.getBoundsInScreen(r)
        val p = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null
        )
        return true
    }

    private fun findPlayNode(n: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        val d = n.contentDescription?.toString()?.lowercase() ?: ""
        if (d.contains("play video") || (d.contains(" - ") && d.contains("seconds") && n.isClickable)) return n
        for (i in 0 until n.childCount) {
            findPlayNode(n.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    /** On YouTube search results: press the first real video. Falls back to a tap where the first result usually is. */
    fun playFirstVideo(fallbackTap: Boolean = false): Boolean {
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString() ?: ""
        if (root != null && pkg.contains("youtube")) {
            val node = findPlayNode(root)
            if (node != null) {
                val t = clickableAncestor(node) ?: node
                if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                val r = android.graphics.Rect(); node.getBoundsInScreen(r)
                if (r.width() > 0) {
                    tapFraction(r.exactCenterX() / screenW(), r.exactCenterY() / screenH()); return true
                }
            }
            // already watching a video? then do nothing
            val inWatch = root.findAccessibilityNodeInfosByText("Minimize").isNotEmpty() ||
                root.findAccessibilityNodeInfosByText("Subscribe").isNotEmpty()
            if (inWatch) return true
        }
        if (fallbackTap && pkg.contains("youtube")) tapFraction(0.5f, 0.33f)
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun global(action: String) {
        when (action) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        }
    }

    /** Android blocks apps from flipping the hotspot directly, so we open the page and press the switch. */
    fun flipHotspotSwitch(): Boolean {
        val root = rootInActiveWindow ?: return false
        val labels = listOf("hotspot", "Hotspot", "Personal Hotspot", "Portable hotspot", "tethering")
        for (l in labels) {
            for (n in root.findAccessibilityNodeInfosByText(l)) {
                // look for a switch inside the same row
                var row: AccessibilityNodeInfo? = n
                var guard = 0
                while (row != null && guard++ < 6) {
                    val sw = findSwitch(row)
                    if (sw != null && sw.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    row = row.parent
                }
                clickableAncestor(n)?.let { if (it.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true }
            }
        }
        return findSwitch(root)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun findSwitch(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val cn = n.className?.toString() ?: ""
        if (cn.contains("Switch") || cn.contains("ToggleButton") || cn.contains("CompoundButton")) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findSwitch(c)?.let { return it }
        }
        return null
    }
}
