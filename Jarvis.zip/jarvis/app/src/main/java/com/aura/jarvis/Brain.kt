package com.aura.jarvis

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Reply(val say: String, val lang: String, val actions: JSONArray, val end: Boolean, val note: String = "")

/** The ChatGPT brain. Talks to OpenAI and gets back speech + phone actions as JSON. */
object Brain {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(100, TimeUnit.SECONDS)
        .build()

    private val history = ArrayList<JSONObject>()

    /** Extra live situation for this session only (e.g. "a call is ringing"). */
    @Volatile var context: String = ""

    fun forget() = history.clear()

    private fun daysUntil(d: Int, m: Int): Int {
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val next = (today.clone() as Calendar).apply {
            set(Calendar.MONTH, m - 1); set(Calendar.DAY_OF_MONTH, d)
        }
        if (next.before(today)) next.add(Calendar.YEAR, 1)
        return ((next.timeInMillis - today.timeInMillis) / 86_400_000L).toInt()
    }

    private fun profile(ctx: Context, owner: String): String {
        val sb = StringBuilder()
        sb.append("ABOUT THE USER ($owner):\n")
        val b = Prefs.birthday(ctx)
        if (b != null) {
            sb.append("- Birthday: day ").append(b[0]).append(", month ").append(b[1])
            if (b[2] > 0) sb.append(", year ").append(b[2])
            sb.append(". Next birthday is in ").append(daysUntil(b[0], b[1])).append(" days (0 = today).\n")
        } else {
            sb.append("- Birthday: not saved yet (if asked, tell them to type it in the Jarvis app, or say: remember my birthday is ...).\n")
        }
        val people = Prefs.get(ctx, Prefs.PEOPLE).trim()
        if (people.isNotEmpty()) sb.append("- People (nickname = saved contact name):\n").append(people).append("\n")
        val facts = Prefs.get(ctx, Prefs.FACTS).trim()
        if (facts.isNotEmpty()) sb.append("- Things they told you to remember:\n").append(facts).append("\n")
        return sb.toString()
    }

    private fun systemPrompt(ctx: Context, owner: String): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val live = if (context.isBlank()) "" else "\nLIVE SITUATION RIGHT NOW: $context\n"
        return """
You are J.A.R.V.I.S., the AI butler from Iron Man, now living inside $owner's Android phone.
Personality: calm, witty, loyal, slightly sarcastic like movie Jarvis, but also a warm friend who can chat casually. Address the user as "sir" or "boss" sometimes (not every sentence). Keep spoken replies SHORT (1-2 sentences) because they are spoken aloud.
Languages: the user speaks English, Hindi or Marathi (often mixed). Always reply in the SAME language the user used. Write Hindi and Marathi in Devanagari script so text-to-speech pronounces it correctly.
Current date and time: $now.
""".trimIndent() + "\n" + profile(ctx, owner) + live + """
You must answer ONLY with one JSON object:
{"say":"what you speak aloud","lang":"en|hi|mr","actions":[ ... ],"end":true|false}
- "end": true when the task is finished or the user says bye/stop/thanks/that's all. false when you asked a question or the chat should continue.
- "actions": list of phone commands to run in order (empty list if just chatting). Available action types:
  {"type":"flashlight","on":true|false}
  {"type":"hotspot"}                      // opens hotspot settings and flips the switch
  {"type":"scroll","dir":"up|down|left|right"}   // dir = the direction the user wants to go; "down" reveals content lower on the page
  {"type":"tap","text":"visible label"}   // tap a button/label on screen by its text
  {"type":"tap","x":0.5,"y":0.5}          // or tap by screen fraction (0..1)
  {"type":"type_text","text":"..."}       // type into the focused text field
  {"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"}
  {"type":"open_app","name":"WhatsApp"}   // use the English app name
  {"type":"play_store_search","query":"..."}
  {"type":"call","name":"Aradhya Patil","alts":["Aradhya","आराध्या","Aaradhya"]}   // call a saved contact. If the user says a relationship or nickname (best friend, mom, bhai, boss...), look it up in the People list or the remembered things above and put the REAL saved contact name in "name". "alts" = other likely spellings (English and Devanagari). Or {"type":"call","number":"+9198..."}
  {"type":"answer_call"}                  // pick up the ringing call
  {"type":"end_call"}                     // reject the ringing call or hang up
  {"type":"speaker","on":true|false}      // loudspeaker during a call
  {"type":"remember","fact":"Aradhya Patil is my best friend"}   // save something the user wants you to remember (birthdays, people, preferences). Use full clear sentences.
  {"type":"alarm","hour":6,"minute":30,"label":"Wake up"}   // 24h clock, compute from current time for relative requests
  {"type":"timer","seconds":300,"label":"Tea"}   // also used for countdowns
  {"type":"make_ppt","title":"Deck title","subtitle":"short tagline","slides":[{"title":"Slide title","bullets":["short point","short point"]}]}
      // when the user asks for a presentation / PPT / slides on a topic. Make 6-8 informative slides (first = overview, last = summary), 3-5 concise bullets each (max ~14 words per bullet), in the user's language (Devanagari for Hindi/Marathi). Do NOT read the slides aloud; "say" is just a short line like "Making your presentation, sir."
  {"type":"deploy_hud"}                   // user asks to deploy / start the 3D HUD (the app narrates the steps itself, keep "say" empty)
  {"type":"open_hud"} {"type":"close_hud"}   // open or close the deployed 3D HUD
  {"type":"web_search","query":"..."}
  {"type":"set_language","code":"en-IN|hi-IN|mr-IN"}  // when the user asks you to listen in another language
Never invent actions outside this list. If you cannot do something, say so honestly in "say" with an empty actions list.
Put the confirmation in "say" in the same turn as the actions (e.g. "Flashlight on, sir.").
If the user asks about their own birthday or people, answer from ABOUT THE USER above.
""".trimIndent()
    }

    fun ask(ctx: Context, userText: String): Reply {
        val key = Prefs.get(ctx, Prefs.OPENAI).trim()
        if (key.isEmpty()) throw IllegalStateException("No OpenAI key")
        val model = Prefs.get(ctx, Prefs.MODEL, "gpt-4o-mini").ifBlank { "gpt-4o-mini" }
        val owner = Prefs.get(ctx, Prefs.OWNER, "Aditya").ifBlank { "the user" }

        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", systemPrompt(ctx, owner)))
        history.forEach { msgs.put(it) }
        val userMsg = JSONObject().put("role", "user").put("content", userText)
        msgs.put(userMsg)

        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.7)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", msgs)

        val req = Request.Builder()
            .url(Prefs.get(ctx, Prefs.BASEURL, "https://api.openai.com/v1").ifBlank { "https://api.openai.com/v1" }.trim().trimEnd('/') + "/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string() ?: ""
            if (!resp.isSuccessful) throw RuntimeException("AI ${resp.code}: ${text.take(200)}")
            val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            val j = JSONObject(content)
            val reply = Reply(
                say = j.optString("say", ""),
                lang = j.optString("lang", "en"),
                actions = j.optJSONArray("actions") ?: JSONArray(),
                end = j.optBoolean("end", false)
            )
            history.add(userMsg)
            history.add(JSONObject().put("role", "assistant").put("content", content))
            while (history.size > 10) history.removeAt(0)
            return reply
        }
    }
}
