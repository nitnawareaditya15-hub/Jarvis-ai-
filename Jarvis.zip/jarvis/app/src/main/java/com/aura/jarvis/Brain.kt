package com.aura.jarvis

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Reply(val say: String, val lang: String, val actions: JSONArray, val end: Boolean)

/** The ChatGPT brain. Talks to OpenAI and gets back speech + phone actions as JSON. */
object Brain {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(100, TimeUnit.SECONDS)
        .build()

    private val history = ArrayList<JSONObject>()

    fun forget() = history.clear()

    private fun systemPrompt(owner: String): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        return """
You are J.A.R.V.I.S., the AI butler from Iron Man, now living inside $owner's Android phone.
Personality: calm, witty, loyal, slightly sarcastic like movie Jarvis, but also a warm friend who can chat casually. Address the user as "sir" or "boss" sometimes (not every sentence). Keep spoken replies SHORT (1-2 sentences) because they are spoken aloud.
Languages: the user speaks English, Hindi or Marathi (often mixed). Always reply in the SAME language the user used. Write Hindi and Marathi in Devanagari script so text-to-speech pronounces it correctly.
Current date and time: $now.

You must answer ONLY with one JSON object:
{"say":"what you speak aloud","lang":"en|hi|mr","actions":[ ... ],"end":true|false}
- "end": true when the task is finished or the user says bye/stop/thanks/that's all. false when you asked a question or the chat should continue.
- "actions": list of phone commands to run in order (empty list if just chatting). Available action types:
  {"type":"flashlight","on":true|false}
  {"type":"hotspot"}                      // opens hotspot settings and flips the switch
  {"type":"scroll","dir":"up|down|left|right"}   // dir = the direction the user wants to go; "down" reveals content lower on the page
  {"type":"tap","text":"visible label"}   // tap a button/label on screen by its text
  {"type":"tap","x":0.5,"y":0.5}          // or tap by screen fraction (0..1)
  {"type":"type_text","text":"..."}       // type into the focused text field
  {"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"}
  {"type":"open_app","name":"WhatsApp"}   // use the English app name
  {"type":"play_store_search","query":"..."}
  {"type":"call","name":"Mom"}            // or {"type":"call","number":"+9198..."}
  {"type":"alarm","hour":6,"minute":30,"label":"Wake up"}   // 24h clock, compute from current time for relative requests
  {"type":"timer","seconds":300,"label":"Tea"}   // also used for countdowns
  {"type":"web_search","query":"..."}
  {"type":"make_ppt","title":"Deck title","subtitle":"short tagline","slides":[{"title":"Slide title","bullets":["short point","short point"]}]}
      // when the user asks for a presentation / PPT / slides on a topic. Make 6-8 informative slides (first = overview, last = summary), 3-5 concise bullets each (max ~14 words per bullet), in the user's language (Devanagari for Hindi/Marathi). Do NOT read the slides aloud; "say" is just a short line like "Making your presentation, sir."
  {"type":"set_language","code":"en-IN|hi-IN|mr-IN"}  // when the user asks you to listen in another language
Never invent actions outside this list. If you cannot do something, say so honestly in "say" with an empty actions list.
Put the confirmation in "say" in the same turn as the actions (e.g. "Flashlight on, sir.").
""".trimIndent()
    }

    fun ask(ctx: Context, userText: String): Reply {
        val key = Prefs.get(ctx, Prefs.OPENAI).trim()
        if (key.isEmpty()) throw IllegalStateException("No OpenAI key")
        val model = Prefs.get(ctx, Prefs.MODEL, "gpt-4o-mini").ifBlank { "gpt-4o-mini" }
        val owner = Prefs.get(ctx, Prefs.OWNER, "Aditya").ifBlank { "the user" }

        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", systemPrompt(owner)))
        history.forEach { msgs.put(it) }
        val userMsg = JSONObject().put("role", "user").put("content", userText)
        msgs.put(userMsg)

        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.7)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", msgs)

        val req = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string() ?: ""
            if (!resp.isSuccessful) throw RuntimeException("OpenAI ${resp.code}: ${text.take(200)}")
            val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            val j = JSONObject(content)
            val reply = Reply(
                say = j.optString("say", ""),
                lang = j.optString("lang", "en"),
                actions = j.optJSONArray("actions") ?: JSONArray(),
                end = j.optBoolean("end", false)
            )
            history.add(userMsg)
            history.add(JSONObject().put("role", "assistant").put("content", content))
            while (history.size > 10) history.removeAt(0)
            return reply
        }
    }
}
