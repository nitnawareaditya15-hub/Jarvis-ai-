package com.aura.jarvis;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Builds a real .pptx (PowerPoint) file with no libraries: dark Jarvis-style slides with orange accents. */
public final class PptxBuilder {
    private PptxBuilder() {}

    private static final String NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main";
    private static final String NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static final String NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main";
    private static final String REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/";
    private static final String HDR = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";

    private static String esc(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&': b.append("&amp;"); break;
                case '<': b.append("&lt;"); break;
                case '>': b.append("&gt;"); break;
                case '"': b.append("&quot;"); break;
                default:
                    if (c >= 0x20 || c == '\n' || c == '\t') b.append(c);
            }
        }
        return b.toString();
    }

    private static void put(ZipOutputStream z, String name, String content) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    /** titles.get(i) / bullets.get(i) describe content slide i. A title slide is added first. */
    public static byte[] build(String deckTitle, String subtitle, List<String> titles, List<List<String>> bullets) throws Exception {
        int n = titles.size() + 1; // + title slide
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ZipOutputStream z = new ZipOutputStream(out);

        StringBuilder ct = new StringBuilder(HDR);
        ct.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
          .append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
          .append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
          .append("<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>")
          .append("<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>")
          .append("<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>")
          .append("<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>");
        for (int i = 1; i <= n; i++)
            ct.append("<Override PartName=\"/ppt/slides/slide").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>");
        ct.append("</Types>");
        put(z, "[Content_Types].xml", ct.toString());

        put(z, "_rels/.rels", HDR + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"" + REL + "officeDocument\" Target=\"ppt/presentation.xml\"/></Relationships>");

        // presentation
        StringBuilder pres = new StringBuilder(HDR);
        pres.append("<p:presentation xmlns:a=\"").append(NS_A).append("\" xmlns:r=\"").append(NS_R).append("\" xmlns:p=\"").append(NS_P).append("\">")
            .append("<p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>");
        for (int i = 1; i <= n; i++) pres.append("<p:sldId id=\"").append(255 + i).append("\" r:id=\"rId").append(i + 1).append("\"/>");
        pres.append("</p:sldIdLst><p:sldSz cx=\"12192000\" cy=\"6858000\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>");
        put(z, "ppt/presentation.xml", pres.toString());

        StringBuilder pr = new StringBuilder(HDR);
        pr.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
          .append("<Relationship Id=\"rId1\" Type=\"").append(REL).append("slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/>");
        for (int i = 1; i <= n; i++)
            pr.append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"").append(REL).append("slide\" Target=\"slides/slide").append(i).append(".xml\"/>");
        pr.append("<Relationship Id=\"rId").append(n + 2).append("\" Type=\"").append(REL).append("theme\" Target=\"theme/theme1.xml\"/></Relationships>");
        put(z, "ppt/_rels/presentation.xml.rels", pr.toString());

        put(z, "ppt/slideMasters/slideMaster1.xml", master());
        put(z, "ppt/slideMasters/_rels/slideMaster1.xml.rels", HDR + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"" + REL + "slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/>"
            + "<Relationship Id=\"rId2\" Type=\"" + REL + "theme\" Target=\"../theme/theme1.xml\"/></Relationships>");
        put(z, "ppt/slideLayouts/slideLayout1.xml", HDR + "<p:sldLayout xmlns:a=\"" + NS_A + "\" xmlns:r=\"" + NS_R + "\" xmlns:p=\"" + NS_P + "\" type=\"blank\" preserve=\"1\">"
            + "<p:cSld name=\"Blank\"><p:spTree>" + grp() + "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>");
        put(z, "ppt/slideLayouts/_rels/slideLayout1.xml.rels", HDR + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"" + REL + "slideMaster\" Target=\"../slideMasters/slideMaster1.xml\"/></Relationships>");
        put(z, "ppt/theme/theme1.xml", theme());

        String slideRels = HDR + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"" + REL + "slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/></Relationships>";

        // title slide
        StringBuilder s1 = slideStart();
        s1.append(rect(2, "Accent", 4572000, 3300000, 3048000, 54000, "FF8C00"));
        s1.append(textBox(3, "Title", 914400, 1500000, 10363200, 1700000, "ctr", "ctr",
            para(deckTitle, 4400, "FF8C00", true, false, "ctr")));
        s1.append(textBox(4, "Subtitle", 914400, 3550000, 10363200, 900000, "t", "ctr",
            para(subtitle == null || subtitle.isEmpty() ? "J.A.R.V.I.S" : subtitle, 2000, "D9D9D9", false, false, "ctr")));
        put(z, "ppt/slides/slide1.xml", slideEnd(s1));
        put(z, "ppt/slides/_rels/slide1.xml.rels", slideRels);

        for (int i = 0; i < titles.size(); i++) {
            List<String> bl = bullets.get(i);
            int chars = 0;
            for (String b : bl) chars += b.length();
            int sz = chars < 330 ? 2600 : (chars < 520 ? 2200 : 1800);
            StringBuilder s = slideStart();
            s.append(rect(2, "Accent", 609600, 520000, 91440, 900000, "FF8C00"));
            s.append(textBox(3, "Title", 840000, 420000, 10700000, 1100000, "ctr", "l",
                para(titles.get(i), 3200, "FF8C00", true, false, "l")));
            StringBuilder body = new StringBuilder();
            for (String b : bl) body.append(para(b, sz, "F2F2F2", false, true, "l"));
            if (bl.isEmpty()) body.append(para("", sz, "F2F2F2", false, false, "l"));
            s.append(textBox(4, "Content", 840000, 1700000, 10700000, 4300000, "t", "l", body.toString()));
            s.append(textBox(5, "Footer", 840000, 6250000, 10700000, 400000, "ctr", "l",
                para("J.A.R.V.I.S   |   " + (i + 2) + " / " + n, 1100, "7F7F7F", false, false, "l")));
            put(z, "ppt/slides/slide" + (i + 2) + ".xml", slideEnd(s));
            put(z, "ppt/slides/_rels/slide" + (i + 2) + ".xml.rels", slideRels);
        }
        z.close();
        return out.toByteArray();
    }

    private static String grp() {
        return "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>"
            + "<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>";
    }

    private static StringBuilder slideStart() {
        return new StringBuilder(HDR + "<p:sld xmlns:a=\"" + NS_A + "\" xmlns:r=\"" + NS_R + "\" xmlns:p=\"" + NS_P + "\"><p:cSld><p:spTree>" + grp());
    }

    private static String slideEnd(StringBuilder b) {
        return b.append("</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>").toString();
    }

    private static String rect(int id, String name, long x, long y, long w, long h, String color) {
        return "<p:sp><p:nvSpPr><p:cNvPr id=\"" + id + "\" name=\"" + name + "\"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>"
            + "<p:spPr><a:xfrm><a:off x=\"" + x + "\" y=\"" + y + "\"/><a:ext cx=\"" + w + "\" cy=\"" + h + "\"/></a:xfrm>"
            + "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val=\"" + color + "\"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>";
    }

    private static String textBox(int id, String name, long x, long y, long w, long h, String anchor, String algn, String paras) {
        return "<p:sp><p:nvSpPr><p:cNvPr id=\"" + id + "\" name=\"" + name + "\"/><p:cNvSpPr txBox=\"1\"/><p:nvPr/></p:nvSpPr>"
            + "<p:spPr><a:xfrm><a:off x=\"" + x + "\" y=\"" + y + "\"/><a:ext cx=\"" + w + "\" cy=\"" + h + "\"/></a:xfrm>"
            + "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>"
            + "<p:txBody><a:bodyPr wrap=\"square\" lIns=\"91440\" tIns=\"45720\" rIns=\"91440\" bIns=\"45720\" anchor=\"" + anchor + "\"><a:normAutofit/></a:bodyPr><a:lstStyle/>"
            + paras + "</p:txBody></p:sp>";
    }

    private static String para(String text, int sz, String color, boolean bold, boolean bullet, String algn) {
        StringBuilder p = new StringBuilder("<a:p><a:pPr algn=\"" + algn + "\"");
        if (bullet) p.append(" marL=\"342900\" indent=\"-342900\"");
        p.append(">");
        if (bullet) p.append("<a:spcBef><a:spcPts val=\"1000\"/></a:spcBef><a:buClr><a:srgbClr val=\"FF8C00\"/></a:buClr><a:buFont typeface=\"Arial\"/><a:buChar char=\"&#8226;\"/>");
        else p.append("<a:buNone/>");
        p.append("</a:pPr>");
        if (text != null && !text.isEmpty()) {
            p.append("<a:r><a:rPr lang=\"en-US\" sz=\"").append(sz).append("\" b=\"").append(bold ? 1 : 0).append("\" dirty=\"0\">")
             .append("<a:solidFill><a:srgbClr val=\"").append(color).append("\"/></a:solidFill></a:rPr><a:t>").append(esc(text)).append("</a:t></a:r>");
        } else {
            p.append("<a:endParaRPr lang=\"en-US\" sz=\"").append(sz).append("\"/>");
        }
        p.append("</a:p>");
        return p.toString();
    }

    private static String master() {
        return HDR + "<p:sldMaster xmlns:a=\"" + NS_A + "\" xmlns:r=\"" + NS_R + "\" xmlns:p=\"" + NS_P + "\"><p:cSld>"
            + "<p:bg><p:bgPr><a:solidFill><a:srgbClr val=\"0B0B0F\"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>"
            + "<p:spTree>" + grp() + "</p:spTree></p:cSld>"
            + "<p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>"
            + "<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst></p:sldMaster>";
    }

    private static String theme() {
        return HDR + "<a:theme xmlns:a=\"" + NS_A + "\" name=\"Jarvis\"><a:themeElements>"
            + "<a:clrScheme name=\"Jarvis\"><a:dk1><a:srgbClr val=\"000000\"/></a:dk1><a:lt1><a:srgbClr val=\"FFFFFF\"/></a:lt1>"
            + "<a:dk2><a:srgbClr val=\"1F1F1F\"/></a:dk2><a:lt2><a:srgbClr val=\"EEEEEE\"/></a:lt2>"
            + "<a:accent1><a:srgbClr val=\"FF8C00\"/></a:accent1><a:accent2><a:srgbClr val=\"FFB347\"/></a:accent2><a:accent3><a:srgbClr val=\"FF6A00\"/></a:accent3>"
            + "<a:accent4><a:srgbClr val=\"FFD27F\"/></a:accent4><a:accent5><a:srgbClr val=\"C25E00\"/></a:accent5><a:accent6><a:srgbClr val=\"808080\"/></a:accent6>"
            + "<a:hlink><a:srgbClr val=\"FFB347\"/></a:hlink><a:folHlink><a:srgbClr val=\"C25E00\"/></a:folHlink></a:clrScheme>"
            + "<a:fontScheme name=\"Jarvis\"><a:majorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont>"
            + "<a:minorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>"
            + "<a:fmtScheme name=\"Jarvis\"><a:fillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:fillStyleLst>"
            + "<a:lnStyleLst><a:ln w=\"6350\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln><a:ln w=\"12700\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln><a:ln w=\"19050\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln></a:lnStyleLst>"
            + "<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>"
            + "<a:bgFillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme>"
            + "</a:themeElements></a:theme>";
    }
}
