package com.aura.jarvis

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** One-time download of the small offline speech model (about 40 MB) used only to spot the word "Jarvis". */
object ModelStore {
    private const val URL_ZIP = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    fun dir(c: Context) = File(c.filesDir, "vosk-model")
    fun ready(c: Context) = File(dir(c), "am").exists() && File(dir(c), "conf").exists()

    fun download(c: Context, progress: (String) -> Unit): Boolean {
        val tmp = File(c.cacheDir, "vosk.zip")
        val target = dir(c)
        try {
            progress("Downloading offline wake engine...")
            val part = File(c.filesDir, "vosk.part")
            var attempts = 0
            var done = false
            while (!done && attempts++ < 6) {
                try {
                    val have = if (part.exists()) part.length() else 0L
                    val conn = URL(URL_ZIP).openConnection() as HttpURLConnection
                    conn.connectTimeout = 20_000
                    conn.readTimeout = 30_000
                    conn.instanceFollowRedirects = true
                    if (have > 0) conn.setRequestProperty("Range", "bytes=$have-")
                    val code = conn.responseCode
                    if (code == 416) { done = true; continue }          // already complete
                    if (code != 200 && code != 206) { progress("Download failed ($code), retrying..."); Thread.sleep(1500); continue }
                    val append = code == 206
                    if (!append) part.delete()
                    val total = conn.contentLength.toLong() + (if (append) have else 0L)
                    var got = if (append) have else 0L
                    var lastPct = -1
                    conn.inputStream.use { ins ->
                        java.io.FileOutputStream(part, append).use { out ->
                            val buf = ByteArray(128 * 1024)
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                got += n
                                if (total > 0) {
                                    val pct = (got * 100 / total).toInt()
                                    if (pct / 5 != lastPct / 5) { lastPct = pct; progress("Downloading wake engine $pct%") }
                                }
                            }
                        }
                    }
                    done = true
                } catch (e: Exception) {
                    progress("Connection dropped, resuming...")
                    Thread.sleep(1500)
                }
            }
            if (!done) { progress("Wake engine download failed - will retry later"); return false }
            part.renameTo(tmp)
            progress("Unpacking wake engine...")
            target.deleteRecursively()
            target.mkdirs()
            val root = target.canonicalPath
            ZipInputStream(tmp.inputStream().buffered()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val slash = e.name.indexOf('/')
                    if (slash < 0) continue
                    val rel = e.name.substring(slash + 1)
                    if (rel.isEmpty()) continue
                    val f = File(target, rel)
                    if (!f.canonicalPath.startsWith(root)) continue   // safety
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { zin.copyTo(it) }
                    }
                }
            }
            tmp.delete()
            val ok = ready(c)
            progress(if (ok) "Wake engine ready" else "Wake engine unpack failed")
            if (!ok) target.deleteRecursively()
            return ok
        } catch (e: Exception) {
            progress("Wake engine download failed: " + (e.message ?: "error").take(60))
            target.deleteRecursively()
            return false
        }
    }
}

/**
 * Listens for "Jarvis" completely offline with AudioRecord + Vosk.
 * Unlike Android's SpeechRecognizer this does NOT grab audio focus, so Reels / YouTube / music keep playing smoothly.
 * It only does work while there is sound, so it is light on CPU and battery.
 */
class WakeEngine(private val ctx: Context, private val waitForPhrase: () -> Boolean, private val onWake: (String) -> Unit) {
    companion object {
        @Volatile private var model: Model? = null
        private const val RATE = 16000
        private const val GRAMMAR = "[\"jarvis\", \"hey jarvis\", \"jarvis wake up\", " +
            "\"jarvis pick up\", \"jarvis pick up the call\", \"hey jarvis pick up the call\", \"jarvis answer the call\", \"jarvis answer\", " +
            "\"jarvis receive the call\", \"jarvis reject the call\", \"jarvis cut the call\", \"jarvis cut\", \"jarvis decline the call\", " +
            "\"jarvis disconnect the call\", \"[unk]\"]"
    }

    @Volatile var sessionId: Int = 0
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "jarvis-wake").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
    }

    private fun loop() {
        var rec: AudioRecord? = null
        var reco: Recognizer? = null
        var free: Recognizer? = null
        try {
            if (model == null) model = Model(ModelStore.dir(ctx).absolutePath)
            reco = Recognizer(model, RATE.toFloat(), GRAMMAR)
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16000)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) return
            sessionId = rec.audioSessionId
            try {   // phone's own far-field helpers, when available
                if (android.media.audiofx.AutomaticGainControl.isAvailable())
                    android.media.audiofx.AutomaticGainControl.create(rec.audioSessionId)?.setEnabled(true)
                if (android.media.audiofx.NoiseSuppressor.isAvailable())
                    android.media.audiofx.NoiseSuppressor.create(rec.audioSessionId)?.setEnabled(true)
            } catch (_: Throwable) {}
            rec.startRecording()
            val buf = ShortArray(1600)            // 100 ms
            var lastLoud = 0L
            var firstHeard = 0L
            var noise = 120f                      // running estimate of room noise (raw peak)
            var env = 400f                        // running estimate of how loud speech is (raw peak)
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) { Thread.sleep(20); continue }
                var raw = 0
                for (i in 0 until n) { val a = if (buf[i] < 0) -buf[i].toInt() else buf[i].toInt(); if (a > raw) raw = a }
                val now = System.currentTimeMillis()
                val gate = maxOf(140f, noise * 2.2f)
                if (raw > gate) {
                    lastLoud = now
                    env = maxOf(raw.toFloat(), env * 0.97f)
                } else {
                    noise = noise * 0.95f + raw * 0.05f
                    env = maxOf(300f, env * 0.995f)
                }
                if (now - lastLoud > 1500) continue     // silence: do nothing, save battery
                // adaptive boost: far / quiet voices get up to x14, close loud voices stay clean
                val gain = (9000f / env).coerceIn(2f, 14f)
                for (i in 0 until n) buf[i] = (buf[i] * gain).toInt().coerceIn(-32768, 32767).toShort()
                val isFinal = reco.acceptWaveForm(buf, n)
                val text = if (isFinal) {
                    JSONObject(reco.result).optString("text")
                } else {
                    JSONObject(reco.partialResult).optString("partial")
                }
                val gHit = text.contains("jarvis")
                var phrase: String? = null
                if (waitForPhrase()) {
                    // a call is ringing: also run a free-speech recogniser so "pick up the call and say I'm busy..." is heard fully
                    if (free == null) free = Recognizer(model, RATE.toFloat())
                    val fr = free
                    var fText = ""
                    var fFinal = false
                    if (fr != null) {
                        fFinal = fr.acceptWaveForm(buf, n)
                        fText = if (fFinal) JSONObject(fr.result).optString("text") else JSONObject(fr.partialResult).optString("partial")
                    }
                    if (gHit && firstHeard == 0L) firstHeard = now
                    if (firstHeard != 0L && (fFinal || now - firstHeard > 5000)) {
                        phrase = if (fText.length > text.length) fText else text
                        fr?.reset()
                    }
                } else {
                    if (free != null) { try { free.close() } catch (_: Exception) {}; free = null }
                    if (gHit) phrase = text
                }
                if (phrase != null) {
                    reco.reset()
                    running = false
                    onWake(phrase)
                    break
                }
            }
        } catch (_: Throwable) {
        } finally {
            try { rec?.stop() } catch (_: Exception) {}
            try { rec?.release() } catch (_: Exception) {}
            try { reco?.close() } catch (_: Exception) {}
            try { free?.close() } catch (_: Exception) {}
        }
    }
}
