package com.aura.jarvis

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** One-time download of the small offline speech model (about 40 MB) used only to spot the word "Jarvis". */
object ModelStore {
    private const val URL_ZIP = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    fun dir(c: Context) = File(c.filesDir, "vosk-model")
    fun ready(c: Context) = File(dir(c), "am").exists() && File(dir(c), "conf").exists()

    fun download(c: Context, progress: (String) -> Unit): Boolean {
        val tmp = File(c.cacheDir, "vosk.zip")
        val target = dir(c)
        try {
            progress("Downloading offline wake engine...")
            val conn = URL(URL_ZIP).openConnection() as HttpURLConnection
            conn.connectTimeout = 20_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            if (conn.responseCode != 200) { progress("Download failed (${conn.responseCode})"); return false }
            val total = conn.contentLength.toLong()
            var got = 0L
            var lastPct = -1
            conn.inputStream.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        if (total > 0) {
                            val pct = (got * 100 / total).toInt()
                            if (pct / 10 != lastPct / 10) { lastPct = pct; progress("Downloading wake engine $pct%") }
                        }
                    }
                }
            }
            progress("Unpacking wake engine...")
            target.deleteRecursively()
            target.mkdirs()
            val root = target.canonicalPath
            ZipInputStream(tmp.inputStream().buffered()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val slash = e.name.indexOf('/')
                    if (slash < 0) continue
                    val rel = e.name.substring(slash + 1)
                    if (rel.isEmpty()) continue
                    val f = File(target, rel)
                    if (!f.canonicalPath.startsWith(root)) continue   // safety
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { zin.copyTo(it) }
                    }
                }
            }
            tmp.delete()
            val ok = ready(c)
            progress(if (ok) "Wake engine ready" else "Wake engine unpack failed")
            if (!ok) target.deleteRecursively()
            return ok
        } catch (e: Exception) {
            progress("Wake engine download failed: " + (e.message ?: "error").take(60))
            target.deleteRecursively()
            return false
        }
    }
}

/**
 * Listens for "Jarvis" completely offline with AudioRecord + Vosk.
 * Unlike Android's SpeechRecognizer this does NOT grab audio focus, so Reels / YouTube / music keep playing smoothly.
 * It only does work while there is sound, so it is light on CPU and battery.
 */
class WakeEngine(private val ctx: Context, private val onWake: () -> Unit) {
    companion object {
        @Volatile private var model: Model? = null
        private const val RATE = 16000
        private const val GRAMMAR = "[\"jarvis\", \"hey jarvis\", \"jarvis wake up\", \"[unk]\"]"
    }

    @Volatile var sessionId: Int = 0
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "jarvis-wake").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
    }

    private fun loop() {
        var rec: AudioRecord? = null
        var reco: Recognizer? = null
        try {
            if (model == null) model = Model(ModelStore.dir(ctx).absolutePath)
            reco = Recognizer(model, RATE.toFloat(), GRAMMAR)
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16000)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) return
            sessionId = rec.audioSessionId
            try {   // phone's own far-field helpers, when available
                if (android.media.audiofx.AutomaticGainControl.isAvailable())
                    android.media.audiofx.AutomaticGainControl.create(rec.audioSessionId)?.setEnabled(true)
                if (android.media.audiofx.NoiseSuppressor.isAvailable())
                    android.media.audiofx.NoiseSuppressor.create(rec.audioSessionId)?.setEnabled(true)
            } catch (_: Throwable) {}
            rec.startRecording()
            val buf = ShortArray(1600)            // 100 ms
            var lastLoud = 0L
            var noise = 120f                      // running estimate of room noise (raw peak)
            var env = 400f                        // running estimate of how loud speech is (raw peak)
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) { Thread.sleep(20); continue }
                var raw = 0
                for (i in 0 until n) { val a = if (buf[i] < 0) -buf[i].toInt() else buf[i].toInt(); if (a > raw) raw = a }
                val now = System.currentTimeMillis()
                val gate = maxOf(140f, noise * 2.2f)
                if (raw > gate) {
                    lastLoud = now
                    env = maxOf(raw.toFloat(), env * 0.97f)
                } else {
                    noise = noise * 0.95f + raw * 0.05f
                    env = maxOf(300f, env * 0.995f)
                }
                if (now - lastLoud > 1500) continue     // silence: do nothing, save battery
                // adaptive boost: far / quiet voices get up to x14, close loud voices stay clean
                val gain = (9000f / env).coerceIn(2f, 14f)
                for (i in 0 until n) buf[i] = (buf[i] * gain).toInt().coerceIn(-32768, 32767).toShort()
                val text = if (reco.acceptWaveForm(buf, n)) {
                    JSONObject(reco.result).optString("text")
                } else {
                    JSONObject(reco.partialResult).optString("partial")
                }
                if (text.contains("jarvis")) {
                    reco.reset()
                    running = false
                    onWake()
                    break
                }
            }
        } catch (_: Throwable) {
        } finally {
            try { rec?.stop() } catch (_: Exception) {}
            try { rec?.release() } catch (_: Exception) {}
            try { reco?.close() } catch (_: Exception) {}
        }
    }
}
