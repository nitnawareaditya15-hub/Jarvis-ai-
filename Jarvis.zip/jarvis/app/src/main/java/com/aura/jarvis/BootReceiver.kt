package com.aura.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Tries to bring Jarvis back after a reboot (newer Android versions may refuse; then open the app once). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Prefs.get(c, "autostart") == "1") {
            try {
                c.startForegroundService(Intent(c, JarvisService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
