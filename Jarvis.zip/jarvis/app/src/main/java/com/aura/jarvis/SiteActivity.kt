package com.aura.jarvis

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.content.FileProvider
import java.io.File

/** Shows the website Jarvis just built, full screen, with Share and Close buttons. */
class SiteActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        val path = intent.getStringExtra("path") ?: run { finish(); return }
        val file = File(path)
        val root = FrameLayout(this)
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.loadUrl("file://" + file.absolutePath)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 8, 8, 8) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.BLACK); textSize = 12f
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 140, 0))
            alpha = 0.92f
            setOnClickListener { f() }
        }
        bar.addView(btn("Share") {
            try {
                val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/html").putExtra(Intent.EXTRA_STREAM, uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share website file"))
            } catch (_: Exception) {}
        })
        bar.addView(btn("Close") { finish() })
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END)
        lp.setMargins(0, 0, 16, 90)
        root.addView(bar, lp)
        setContentView(root)
    }
}
