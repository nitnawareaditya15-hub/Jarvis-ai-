package com.aura.jarvis

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.*

/**
 * The Iron-Man style holographic orb: your picture as the HUD backdrop with a live 3D
 * particle sphere, orbit rings and glowing core drawn on top (additive "screen" blending).
 */
class OrbView(ctx: Context) : View(ctx) {

    enum class State { LISTENING, THINKING, SPEAKING }

    @Volatile var state = State.LISTENING
    @Volatile var level = 0f          // 0..1 voice energy
    @Volatile var caption = ""

    private val bmp: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.jarvis_orb)
    private val t0 = SystemClock.uptimeMillis()
    private var last = t0
    private var angY = 0f
    private var angX = 0.4f
    private var smooth = 0f

    private val N = 1100
    private val px = FloatArray(N); private val py = FloatArray(N); private val pz = FloatArray(N)
    private val sx = FloatArray(N); private val sy = FloatArray(N); private val sz = FloatArray(N)

    private val screen = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    private val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { xfermode = null }
    private val dotFar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 110, 0); strokeCap = Paint.Cap.ROUND; xfermode = screen }
    private val dotMid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 160, 20); strokeCap = Paint.Cap.ROUND; xfermode = screen }
    private val dotNear = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 215, 120); strokeCap = Paint.Cap.ROUND; xfermode = screen }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = screen }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(255, 140, 0); xfermode = screen; strokeCap = Paint.Cap.ROUND
    }
    private val title = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 170, 40); typeface = Typeface.create("sans-serif-thin", Typeface.BOLD)
        textAlign = Paint.Align.CENTER; letterSpacing = 0.5f
    }
    private val cap = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 196, 110); typeface = Typeface.MONOSPACE
    }
    private val pts0 = FloatArray(N * 2)

    init {
        setBackgroundColor(Color.BLACK)
        setLayerType(LAYER_TYPE_HARDWARE, null)
        val ga = PI * (3 - sqrt(5.0))
        for (i in 0 until N) {
            val y = 1 - 2 * (i + 0.5f) / N
            val r = sqrt(1 - y * y)
            val th = ga * i
            px[i] = (cos(th) * r).toFloat(); py[i] = y; pz[i] = (sin(th) * r).toFloat()
        }
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = min(0.05f, (now - last) / 1000f); last = now
        val t = (now - t0) / 1000f
        val w = width.toFloat(); val h = height.toFloat()
        smooth += (level - smooth) * 0.25f

        val speed = when (state) {
            State.LISTENING -> 0.55f
            State.THINKING -> 2.4f
            State.SPEAKING -> 0.9f + smooth * 1.8f
        }
        angY += speed * dt
        angX = 0.45f + 0.15f * sin(t * 0.4f)

        val cx = w / 2f; val cy = h * 0.42f
        val pulse = 1f + 0.025f * sin(t * 2.2f) + smooth * 0.10f

        // --- backdrop image (your reference) breathing slowly
        bmp?.let {
            val iw = w * 1.02f * (1f + 0.02f * sin(t * 0.8f)) * (1f + smooth * 0.03f)
            val ih = iw * it.height / it.width
            val dst = RectF(cx - iw / 2, cy - ih / 2, cx + iw / 2, cy + ih / 2)
            imgPaint.alpha = (200 + 55 * sin(t * 1.3f)).toInt().coerceIn(120, 255)
            c.drawBitmap(it, null, dst, imgPaint)
        }

        val R = w * 0.27f * pulse

        // --- backlight bloom
        val bloom = R * (2.3f + smooth * 0.8f)
        glow.shader = RadialGradient(cx, cy, bloom,
            intArrayOf(Color.argb(150 + (smooth * 80).toInt().coerceAtMost(100), 255, 120, 10), Color.argb(55, 255, 80, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, bloom, glow)

        // --- 3D particle sphere
        val cy1 = cos(angY); val sy1 = sin(angY)
        val cx1 = cos(angX); val sx1 = sin(angX)
        val fov = 3.2f
        var nf = 0; var nm = 0; var nn = 0
        val far = FloatArray(N * 2); val mid = FloatArray(N * 2); val near = FloatArray(N * 2)
        val wob = 1f + 0.06f * sin(t * 3f) + smooth * 0.15f
        for (i in 0 until N) {
            var x = px[i]; var y = py[i]; var z = pz[i]
            // slight breathing / noise displacement
            val k = wob + 0.05f * sin(i * 0.37f + t * 2f)
            x *= k; y *= k; z *= k
            val x1 = x * cy1 + z * sy1
            val z1 = -x * sy1 + z * cy1
            val y2 = y * cx1 - z1 * sx1
            val z2 = y * sx1 + z1 * cx1
            val s = fov / (fov - z2)
            val X = cx + x1 * R * s; val Y = cy + y2 * R * s
            sx[i] = X; sy[i] = Y; sz[i] = z2
            when {
                z2 > 0.35f -> { near[nn * 2] = X; near[nn * 2 + 1] = Y; nn++ }
                z2 > -0.35f -> { mid[nm * 2] = X; mid[nm * 2 + 1] = Y; nm++ }
                else -> { far[nf * 2] = X; far[nf * 2 + 1] = Y; nf++ }
            }
        }
        dotFar.strokeWidth = w * 0.0035f; dotMid.strokeWidth = w * 0.0055f; dotNear.strokeWidth = w * 0.0085f
        dotFar.alpha = 120; dotMid.alpha = 190; dotNear.alpha = 255
        c.drawPoints(far, 0, nf * 2, dotFar)
        c.drawPoints(mid, 0, nm * 2, dotMid)
        c.drawPoints(near, 0, nn * 2, dotNear)

        // --- electric filaments linking nearby front points
        ring.strokeWidth = w * 0.0016f; ring.alpha = 90
        var j = 0
        var drawn = 0
        while (j < N - 7 && drawn < 70) {
            val a = (j * 13 + (t * 8).toInt() * 7) % N
            val b = (a + 5 + (j % 11)) % N
            if (sz[a] > 0f && sz[b] > 0f) { c.drawLine(sx[a], sy[a], sx[b], sy[b], ring); drawn++ }
            j += 3
        }

        // --- orbit rings (3 tilted ellipses)
        for (r in 0 until 3) {
            val tilt = r * 60f + t * (8f + 6f * r) * if (state == State.THINKING) 3f else 1f
            c.save()
            c.rotate(tilt, cx, cy)
            ring.alpha = 150 - r * 30
            ring.strokeWidth = w * (0.004f - r * 0.001f)
            val rx = R * (1.55f + r * 0.18f); val ry = rx * (0.28f + 0.05f * r)
            val oval = RectF(cx - rx, cy - ry, cx + rx, cy + ry)
            val sweep = 200f + 60f * sin(t + r)
            c.drawArc(oval, t * (40f + r * 25f), sweep, false, ring)
            c.restore()
        }
        // HUD circle segments
        ring.alpha = 200; ring.strokeWidth = w * 0.006f
        val hr = R * 1.95f
        val hudRect = RectF(cx - hr, cy - hr, cx + hr, cy + hr)
        for (s in 0 until 6) c.drawArc(hudRect, -t * 30f + s * 60f, 34f, false, ring)
        ring.strokeWidth = w * 0.002f; ring.alpha = 120
        val hr2 = R * 2.15f
        c.drawArc(RectF(cx - hr2, cy - hr2, cx + hr2, cy + hr2), t * 55f, 250f, false, ring)

        // --- hot core
        val core = R * (0.28f + smooth * 0.22f) * (1f + 0.08f * sin(t * 6f))
        glow.shader = RadialGradient(cx, cy, core * 2.6f,
            intArrayOf(Color.argb(255, 255, 250, 220), Color.argb(230, 255, 190, 60), Color.argb(90, 255, 100, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 0.25f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, core * 2.6f, glow)

        // --- voice-reactive rim bars
        ring.strokeWidth = w * 0.004f
        val bars = 60
        for (b in 0 until bars) {
            val a = b * 2 * PI / bars + t * 0.3
            val m = (0.35f + 0.65f * abs(sin(b * 0.9f + t * 5f))) * (0.15f + smooth)
            val r0 = R * 2.3f; val r1 = r0 + R * 0.35f * m
            ring.alpha = (80 + 150 * m).toInt().coerceAtMost(255)
            c.drawLine(cx + cos(a).toFloat() * r0, cy + sin(a).toFloat() * r0, cx + cos(a).toFloat() * r1, cy + sin(a).toFloat() * r1, ring)
        }

        // --- text
        title.textSize = w * 0.06f
        c.drawText("J.A.R.V.I.S", cx, h * 0.075f, title)
        title.textSize = w * 0.032f; title.alpha = 200
        c.drawText(when (state) {
            State.LISTENING -> "LISTENING"
            State.THINKING -> "PROCESSING"
            State.SPEAKING -> "ONLINE"
        }, cx, h * 0.105f, title)
        title.alpha = 255

        if (caption.isNotBlank()) {
            cap.textSize = w * 0.045f
            val layout = StaticLayout.Builder.obtain(caption, 0, caption.length, cap, (w * 0.84f).toInt())
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(5).setEllipsize(android.text.TextUtils.TruncateAt.END).build()
            c.save(); c.translate(w * 0.08f, h * 0.76f); layout.draw(c); c.restore()
        }

        postInvalidateOnAnimation()
    }
}
