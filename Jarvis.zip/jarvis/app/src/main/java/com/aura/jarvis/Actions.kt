package com.aura.jarvis

import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.widget.Toast
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/** Runs the phone commands that ChatGPT asks for. */
class Actions(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())

    private val aliases = mapOf(
        "insta" to "instagram", "yt" to "youtube", "whatsapp" to "whatsapp",
        "chrome" to "chrome", "maps" to "maps", "play store" to "play store",
        "gallery" to "gallery", "camera" to "camera", "settings" to "settings",
        "clock" to "clock", "calculator" to "calculator", "phone" to "phone"
    )

    fun run(actions: JSONArray, done: () -> Unit) {
        runAt(actions, 0, done)
    }

    private fun runAt(actions: JSONArray, i: Int, done: () -> Unit) {
        if (i >= actions.length()) {
            done(); return
        }
        val a = actions.optJSONObject(i)
        val wait = try {
            if (a != null) exec(a) else 0L
        } catch (e: Exception) {
            0L
        }
        main.postDelayed({ runAt(actions, i + 1, done) }, wait)
    }

    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    /** Returns how long to wait (ms) before the next action. */
    private fun exec(a: JSONObject): Long {
        val hands = JarvisAccessibilityService.instance
        when (a.optString("type")) {
            "flashlight" -> { torch(a.optBoolean("on", true)); return 300 }

            "hotspot" -> {
                val intents = listOf(
                    Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
                    Intent(Settings.ACTION_WIRELESS_SETTINGS)
                )
                for (it in intents) {
                    try { launch(it); break } catch (_: Exception) {}
                }
                main.postDelayed({ hands?.flipHotspotSwitch() }, 1800)
                return 2600
            }

            "scroll" -> { hands?.scroll(a.optString("dir", "down")); return 700 }

            "tap" -> {
                if (a.has("text")) hands?.tapText(a.getString("text"))
                else hands?.tapFraction(a.optDouble("x", 0.5).toFloat(), a.optDouble("y", 0.5).toFloat())
                return 800
            }

            "type_text" -> { hands?.typeText(a.optString("text")); return 500 }
            "back", "home", "recents", "notifications" -> { hands?.global(a.getString("type")); return 700 }

            "open_app" -> { openApp(a.optString("name")); return 1600 }

            "play_store_search" -> {
                val q = Uri.encode(a.optString("query"))
                try {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$q&c=apps")).setPackage("com.android.vending"))
                } catch (_: Exception) {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=$q&c=apps")))
                }
                return 1500
            }

            "call" -> {
                var number = a.optString("number", "")
                if (number.isBlank()) number = findNumber(a.optString("name")) ?: ""
                if (number.isNotBlank()) {
                    try {
                        launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
                    } catch (_: SecurityException) {
                        launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
                    }
                } else {
                    launch(Intent(Intent.ACTION_DIAL))
                }
                return 1500
            }

            "alarm" -> {
                launch(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis alarm"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                return 800
            }

            "timer" -> {
                launch(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis timer"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                return 800
            }

            "web_search" -> {
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
                return 1200
            }

            "make_ppt" -> { makePpt(a); return 2500 }

            "set_language" -> {
                Prefs.put(ctx, Prefs.LANG, a.optString("code", "en-IN"))
                return 100
            }
        }
        return 0
    }

    private fun makePpt(a: JSONObject) {
        try {
            val arr = a.optJSONArray("slides") ?: return
            val titles = ArrayList<String>()
            val bullets = ArrayList<List<String>>()
            for (i in 0 until minOf(arr.length(), 15)) {
                val o = arr.optJSONObject(i) ?: continue
                titles.add(o.optString("title", "Slide ${i + 1}"))
                val bl = ArrayList<String>()
                val ba = o.optJSONArray("bullets")
                if (ba != null) for (j in 0 until minOf(ba.length(), 7)) bl.add(ba.optString(j))
                bullets.add(bl)
            }
            if (titles.isEmpty()) return
            val title = a.optString("title", "Presentation").ifBlank { "Presentation" }
            val bytes = PptxBuilder.build(title, a.optString("subtitle", ""), titles, bullets)
            val safe = title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().ifBlank { "Presentation" }.take(40)
            val name = "$safe ${System.currentTimeMillis() % 100000}.pptx"
            val mime = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            if (Build.VERSION.SDK_INT < 29) {
                Toast.makeText(ctx, "PPT needs Android 10 or newer", Toast.LENGTH_LONG).show(); return
            }
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Jarvis")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
            ctx.contentResolver.update(uri, cv, null, null)
            Toast.makeText(ctx, "Saved: Downloads/Jarvis/$name", Toast.LENGTH_LONG).show()
            try {
                launch(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (_: Exception) {
                Toast.makeText(ctx, "Install WPS Office or PowerPoint to open it", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "PPT failed: " + (e.message ?: "error").take(60), Toast.LENGTH_LONG).show()
        }
    }

    private fun torch(on: Boolean) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (id in cm.cameraIdList) {
            val has = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
            if (has) {
                cm.setTorchMode(id, on)
                return
            }
        }
    }

    private fun openApp(name: String) {
        val wanted = (aliases[name.lowercase().trim()] ?: name).lowercase().trim()
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        var best: String? = null
        for (r in apps) {
            val label = r.loadLabel(pm).toString().lowercase()
            if (label == wanted) { best = r.activityInfo.packageName; break }
            if (best == null && (label.contains(wanted) || wanted.contains(label))) best = r.activityInfo.packageName
        }
        val intent = best?.let { pm.getLaunchIntentForPackage(it) }
        if (intent != null) launch(intent)
    }

    private fun findNumber(name: String): String? {
        if (name.isBlank()) return null
        return try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%$name%"), null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: SecurityException) {
            null
        }
    }
}
