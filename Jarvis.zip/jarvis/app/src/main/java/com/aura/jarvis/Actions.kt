package com.aura.jarvis

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Runs the phone commands that ChatGPT asks for. */
class Actions(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())

    private val aliases = mapOf(
        "insta" to "instagram", "yt" to "youtube", "whatsapp" to "whatsapp",
        "chrome" to "chrome", "maps" to "maps", "play store" to "play store",
        "gallery" to "gallery", "camera" to "camera", "settings" to "settings",
        "clock" to "clock", "calculator" to "calculator", "phone" to "phone"
    )

    fun run(actions: JSONArray, done: () -> Unit) {
        runAt(actions, 0, done)
    }

    private fun runAt(actions: JSONArray, i: Int, done: () -> Unit) {
        if (i >= actions.length()) {
            done(); return
        }
        val a = actions.optJSONObject(i)
        val wait = try {
            if (a != null) exec(a) else 0L
        } catch (e: Exception) {
            0L
        }
        main.postDelayed({ runAt(actions, i + 1, done) }, wait)
    }

    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    /** Returns how long to wait (ms) before the next action. */
    private fun exec(a: JSONObject): Long {
        val hands = JarvisAccessibilityService.instance
        when (a.optString("type")) {
            "flashlight" -> { torch(a.optBoolean("on", true)); return 300 }

            "hotspot" -> {
                val intents = listOf(
                    Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
                    Intent(Settings.ACTION_WIRELESS_SETTINGS)
                )
                for (it in intents) {
                    try { launch(it); break } catch (_: Exception) {}
                }
                main.postDelayed({ hands?.flipHotspotSwitch() }, 1800)
                return 2600
            }

            "scroll" -> { hands?.scroll(a.optString("dir", "down")); return 700 }

            "tap" -> {
                if (a.has("text")) hands?.tapText(a.getString("text"))
                else hands?.tapFraction(a.optDouble("x", 0.5).toFloat(), a.optDouble("y", 0.5).toFloat())
                return 800
            }

            "type_text" -> { hands?.typeText(a.optString("text")); return 500 }
            "back", "home", "recents", "notifications" -> { hands?.global(a.getString("type")); return 700 }

            "open_app" -> { openApp(a.optString("name")); return 1600 }

            "play_store_search" -> {
                val q = Uri.encode(a.optString("query"))
                try {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$q&c=apps")).setPackage("com.android.vending"))
                } catch (_: Exception) {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=$q&c=apps")))
                }
                return 1500
            }

            "call" -> {
                var number = a.optString("number", "")
                if (number.isBlank()) {
                    val names = ArrayList<String>()
                    names.add(a.optString("name"))
                    val alts = a.optJSONArray("alts")
                    if (alts != null) for (k in 0 until alts.length()) names.add(alts.optString(k))
                    number = findNumber(names) ?: ""
                    if (number.isBlank()) {
                        Toast.makeText(ctx, "Contact not found: " + a.optString("name"), Toast.LENGTH_LONG).show()
                    }
                }
                if (number.isNotBlank()) {
                    try {
                        launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
                    } catch (_: SecurityException) {
                        launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
                    }
                } else {
                    launch(Intent(Intent.ACTION_DIAL))
                }
                return 1500
            }

            "answer_call" -> {
                try {
                    val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                    tm.acceptRingingCall()
                } catch (e: SecurityException) {
                    Toast.makeText(ctx, "Allow 'phone calls' permission in the Jarvis app", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {}
                return 1500
            }

            "end_call" -> {
                try {
                    if (Build.VERSION.SDK_INT >= 28) {
                        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                        tm.endCall()
                    }
                } catch (e: SecurityException) {
                    Toast.makeText(ctx, "Allow 'phone calls' permission in the Jarvis app", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {}
                return 800
            }

            "speaker" -> {
                try {
                    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    @Suppress("DEPRECATION")
                    am.isSpeakerphoneOn = a.optBoolean("on", true)
                } catch (_: Exception) {}
                return 300
            }

            "remember" -> {
                val fact = a.optString("fact").trim()
                if (fact.isNotEmpty()) {
                    val old = Prefs.get(ctx, Prefs.FACTS).trim()
                    val all = (if (old.isEmpty()) fact else "$old\n$fact").lines().takeLast(40)
                    Prefs.put(ctx, Prefs.FACTS, all.joinToString("\n"))
                }
                return 100
            }

            "alarm" -> {
                launch(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis alarm"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                return 800
            }

            "timer" -> {
                launch(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis timer"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                return 800
            }

            "web_search" -> {
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
                return 1200
            }

            "make_ppt" -> { makePpt(a); return 2500 }

            "toggle_setting" -> { toggleSetting(a); return 4500 }

            "volume" -> {
                try {
                    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val stream = when (a.optString("stream", "music")) {
                        "ring" -> AudioManager.STREAM_RING
                        "alarm" -> AudioManager.STREAM_ALARM
                        else -> AudioManager.STREAM_MUSIC
                    }
                    val max = am.getStreamMaxVolume(stream)
                    val pct = a.optInt("percent", 50).coerceIn(0, 100)
                    am.setStreamVolume(stream, (max * pct / 100f).toInt(), AudioManager.FLAG_SHOW_UI)
                } catch (_: Exception) {}
                return 400
            }

            "brightness" -> {
                if (Settings.System.canWrite(ctx)) {
                    val pct = a.optInt("percent", 50).coerceIn(1, 100)
                    Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (pct * 255 / 100))
                } else askWriteSettings()
                return 400
            }

            "add_widget" -> {
                val date = a.optString("date", "").trim()
                if (date.isNotEmpty()) Prefs.put(ctx, Prefs.WDATE, date)
                else Prefs.put(ctx, Prefs.WDATE, "")
                Prefs.put(ctx, Prefs.WLABEL, a.optString("label", "").trim())
                CountdownWidget.refresh(ctx)
                if (!CountdownWidget.requestPin(ctx)) {
                    Toast.makeText(ctx, "Long-press the home screen > Widgets > Jarvis Countdown", Toast.LENGTH_LONG).show()
                }
                return 1500
            }

            "lock_phone" -> { hands?.lockScreen(); return 800 }

            "make_website" -> { makeWebsite(a); return 2500 }

            "open_url" -> {
                var u = a.optString("url").trim()
                if (u.isNotEmpty()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                }
                return 1500
            }

            "youtube_play" -> {
                val q = Uri.encode(a.optString("query"))
                val url = Uri.parse("https://www.youtube.com/results?search_query=$q")
                try {
                    launch(Intent(Intent.ACTION_VIEW, url).setPackage("com.google.android.youtube"))
                } catch (_: Exception) {
                    launch(Intent(Intent.ACTION_VIEW, url))
                }
                // wait for results to load, then press the first video (retry a couple of times)
                main.postDelayed({ hands?.playFirstVideo() }, 4200)
                main.postDelayed({ hands?.playFirstVideo(true) }, 7000)
                return 9500
            }

            "set_language" -> {
                Prefs.put(ctx, Prefs.LANG, a.optString("code", "en-IN"))
                return 100
            }
        }
        return 0
    }

    private fun makePpt(a: JSONObject) {
        try {
            val arr = a.optJSONArray("slides") ?: return
            val titles = ArrayList<String>()
            val bullets = ArrayList<List<String>>()
            for (i in 0 until minOf(arr.length(), 15)) {
                val o = arr.optJSONObject(i) ?: continue
                titles.add(o.optString("title", "Slide ${i + 1}"))
                val bl = ArrayList<String>()
                val ba = o.optJSONArray("bullets")
                if (ba != null) for (j in 0 until minOf(ba.length(), 7)) bl.add(ba.optString(j))
                bullets.add(bl)
            }
            if (titles.isEmpty()) return
            val title = a.optString("title", "Presentation").ifBlank { "Presentation" }
            val bytes = PptxBuilder.build(title, a.optString("subtitle", ""), titles, bullets)
            val safe = title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().ifBlank { "Presentation" }.take(40)
            val name = "$safe ${System.currentTimeMillis() % 100000}.pptx"
            val mime = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            if (Build.VERSION.SDK_INT < 29) {
                Toast.makeText(ctx, "PPT needs Android 10 or newer", Toast.LENGTH_LONG).show(); return
            }
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Jarvis")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
            ctx.contentResolver.update(uri, cv, null, null)
            Toast.makeText(ctx, "Saved: Downloads/Jarvis/$name", Toast.LENGTH_LONG).show()
            try {
                launch(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (_: Exception) {
                Toast.makeText(ctx, "Install WPS Office or PowerPoint to open it", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "PPT failed: " + (e.message ?: "error").take(60), Toast.LENGTH_LONG).show()
        }
    }

    private fun askWriteSettings() {
        Toast.makeText(ctx, "Allow 'Modify system settings' for Jarvis, then ask again", Toast.LENGTH_LONG).show()
        try {
            launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
        } catch (_: Exception) {}
    }

    private fun toggleSetting(a: JSONObject) {
        val hands = JarvisAccessibilityService.instance
        val name = a.optString("name").lowercase().replace(" ", "_").replace("-", "_")
        val on: Boolean? = if (a.has("on")) a.optBoolean("on", true) else null

        if (name == "autorotate" || name == "auto_rotate" || name == "rotation" || name == "rotate") {
            if (Settings.System.canWrite(ctx)) {
                val cur = Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
                val want = on ?: !cur
                Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (want) 1 else 0)
                Toast.makeText(ctx, "Auto-rotate " + (if (want) "ON" else "OFF"), Toast.LENGTH_SHORT).show()
            } else askWriteSettings()
            return
        }

        // Settings pages that have one big switch on top
        val page: String? = when (name) {
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "airplane", "airplane_mode", "flight_mode" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "wifi", "wi_fi" -> Settings.ACTION_WIFI_SETTINGS
            "location", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "battery_saver", "power_saving" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            else -> null
        }
        if (page != null) {
            try { launch(Intent(page)) } catch (_: Exception) { return }
            main.postDelayed({ hands?.setSwitch(on) }, 1800)
            main.postDelayed({ hands?.global("back") }, 3000)
            return
        }

        // Everything else: press the tile in the quick-settings panel
        val tile: List<String> = when (name) {
            "mobile_data", "data", "internet", "cellular" -> listOf("Mobile data", "Mobile Data", "Cellular data", "Data")
            "dnd", "do_not_disturb", "silent" -> listOf("Do Not Disturb", "Do not disturb", "DND", "Silent")
            "dark_mode", "dark_theme" -> listOf("Dark mode", "Dark theme")
            "screen_record", "screen_recorder" -> listOf("Screen record", "Screen Recorder", "Record")
            "hotspot" -> listOf("Hotspot", "Mobile hotspot")
            "auto_brightness" -> listOf("Auto brightness")
            else -> listOf(a.optString("name"))
        }
        if (hands == null) {
            Toast.makeText(ctx, "Turn on Accessibility > Jarvis Hands first", Toast.LENGTH_LONG).show(); return
        }
        hands.clickTile(tile) { main.postDelayed({ hands.global("home") }, 500) }
    }

    private fun makeWebsite(a: JSONObject) {
        try {
            val html = a.optString("html")
            if (html.length < 50) {
                Toast.makeText(ctx, "Website was empty, try again", Toast.LENGTH_LONG).show(); return
            }
            val title = a.optString("title", "Website").ifBlank { "Website" }
            val safe = title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().ifBlank { "Website" }.take(40)
            val name = "$safe ${System.currentTimeMillis() % 100000}.html"
            val dir = java.io.File(ctx.filesDir, "sites").apply { mkdirs() }
            val f = java.io.File(dir, name)
            f.writeText(html)
            if (Build.VERSION.SDK_INT >= 29) {
                try {
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "text/html")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Jarvis")
                    }
                    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    if (uri != null) ctx.contentResolver.openOutputStream(uri)?.use { it.write(html.toByteArray()) }
                } catch (_: Exception) {}
            }
            Toast.makeText(ctx, "Website saved: Downloads/Jarvis/$name", Toast.LENGTH_LONG).show()
            launch(Intent(ctx, SiteActivity::class.java).putExtra("path", f.absolutePath).putExtra("title", title))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Website failed: " + (e.message ?: "error").take(60), Toast.LENGTH_LONG).show()
        }
    }

    private fun torch(on: Boolean) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (id in cm.cameraIdList) {
            val has = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
            if (has) {
                cm.setTorchMode(id, on)
                return
            }
        }
    }

    private fun openApp(name: String) {
        val wanted = (aliases[name.lowercase().trim()] ?: name).lowercase().trim()
        val pm = ctx.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(mainIntent, 0)
        var best: String? = null
        for (r in apps) {
            val label = r.loadLabel(pm).toString().lowercase()
            if (label == wanted) { best = r.activityInfo.packageName; break }
            if (best == null && (label.contains(wanted) || wanted.contains(label))) best = r.activityInfo.packageName
        }
        val intent = best?.let { pm.getLaunchIntentForPackage(it) }
        if (intent != null) launch(intent)
    }

    private fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim().replace(Regex("\\s+"), " ")

    /** Finds the best matching contact for any of the given spellings. */
    private fun findNumber(names: List<String>): String? {
        val wanted = names.map { norm(it) }.filter { it.isNotBlank() }
        if (wanted.isEmpty()) return null
        var best: String? = null
        var bestScore = 0
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val cname = norm(c.getString(0) ?: "")
                    val num = c.getString(1) ?: continue
                    if (cname.isEmpty()) continue
                    for (w in wanted) {
                        var sc = 0
                        if (cname == w) sc = 100
                        else if (cname.contains(w) || w.contains(cname)) sc = 70
                        else {
                            val hits = w.split(" ").count { it.length >= 3 && cname.contains(it) }
                            if (hits > 0) sc = 30 + 10 * hits
                        }
                        if (sc > bestScore) { bestScore = sc; best = num }
                    }
                }
            }
        } catch (e: SecurityException) {
            return null
        }
        return if (bestScore >= 40) best else null
    }
}
