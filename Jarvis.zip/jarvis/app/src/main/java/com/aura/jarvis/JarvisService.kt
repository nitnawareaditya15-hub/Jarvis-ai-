package com.aura.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import java.util.Locale

/**
 * Always-on Jarvis. Runs as a foreground service so it keeps listening for "Jarvis"
 * even when the app is closed, then shows the orb over everything and talks.
 */
class JarvisService : Service() {

    companion object {
        const val ACTION_STOP = "com.aura.jarvis.STOP"
        const val ACTION_TEST = "com.aura.jarvis.TEST"
        @Volatile var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var wakeRec: SpeechRecognizer? = null
    private var wakeLoop = false
    private val wakeRestart = Runnable { listenForWake() }
    private val wakeWords = listOf("jarvis", "jarvish", "jarwis", "jarvas", "जार्विस", "जारविस", "जर्विस", "जार्विश", "जारवीस", "जर्वीस", "जार्विज")
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wm: WindowManager? = null
    private var orb: OrbView? = null
    private var wake: PowerManager.WakeLock? = null
    private var active = false
    private var listenFails = 0
    private lateinit var actions: Actions

    private val sessionTimeout = Runnable { endSession() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        actions = Actions(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setPitch(0.85f)
                tts?.setSpeechRate(0.97f)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        startInForeground()
        running = true
        if (!wakeLoop) startWakeWord()
        if (intent?.action == ACTION_TEST) main.postDelayed({ beginSession() }, 400)
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("jarvis", "Jarvis standby", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is online")
            .setContentText("Say \"Hey Jarvis\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1, n)
    }

    // ------------------------------------------------------------ wake word
    // No extra key needed: we keep Android's own speech recogniser listening for the word "Jarvis".
    private fun startWakeWord() {
        wakeLoop = true
        muteBeep(true)
        listenForWake()
    }

    private fun stopWake() {
        wakeLoop = false
        main.removeCallbacks(wakeRestart)
        try { wakeRec?.destroy() } catch (_: Exception) {}
        wakeRec = null
        muteBeep(false)
    }

    private fun muteBeep(on: Boolean) {
        if (Prefs.get(this, "mute") != "1") return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val dir = if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, dir, 0)
            am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, dir, 0)
        } catch (_: Exception) {}
    }

    private fun heardWake(b: Bundle?): Boolean {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return false
        for (s in list) {
            val t = s.lowercase()
            if (wakeWords.any { t.contains(it) }) return true
        }
        return false
    }

    private fun listenForWake() {
        if (!wakeLoop || active) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNote("Speech recognition not available on this phone"); return
        }
        try { wakeRec?.destroy() } catch (_: Exception) {}
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        wakeRec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                if (wakeLoop && !active && heardWake(p)) main.post { beginSession() }
            }
            override fun onResults(res: Bundle?) {
                if (wakeLoop && !active && heardWake(res)) main.post { beginSession() }
                else main.postDelayed(wakeRestart, 150)
            }
            override fun onError(e: Int) {
                if (!wakeLoop || active) return
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    updateNote("Allow the microphone permission in the app"); return
                }
                val wait = if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == 10) 2000L else 300L
                main.removeCallbacks(wakeRestart)
                main.postDelayed(wakeRestart, wait)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try { r.startListening(i) } catch (_: Exception) { main.postDelayed(wakeRestart, 1000) }
    }

    private fun updateNote(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        nm.notify(1, n)
    }

    // ------------------------------------------------------------ session
    private fun beginSession() {
        if (active) return
        active = true
        listenFails = 0
        stopWake()
        Brain.forget()

        @Suppress("DEPRECATION")
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "jarvis:wake"
        ).also { it.acquire(90_000) }

        showOrb()
        val lang = Prefs.get(this, Prefs.LANG, "hi-IN")
        val greet = when (lang) {
            "hi-IN" -> "जी सर?" to "hi"
            "mr-IN" -> "हो सर?" to "mr"
            else -> listOf("Yes, sir?", "At your service.", "Online and ready, sir.").random() to "en"
        }
        orb?.caption = greet.first
        orb?.state = OrbView.State.SPEAKING
        speak(greet.first, greet.second) { listen() }
        main.removeCallbacks(sessionTimeout)
        main.postDelayed(sessionTimeout, 80_000)
    }

    private fun endSession() {
        main.removeCallbacks(sessionTimeout)
        recognizer?.destroy(); recognizer = null
        tts?.stop()
        hideOrb()
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        active = false
        startWakeWord()
    }

    // ------------------------------------------------------------ overlay
    private fun showOrb() {
        if (!Settings.canDrawOverlays(this)) return
        val v = OrbView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )
        v.alpha = 0f
        try {
            wm?.addView(v, lp)
            v.animate().alpha(1f).setDuration(450).start()
            orb = v
        } catch (_: Exception) {}
    }

    private fun hideOrb() {
        val v = orb ?: return
        orb = null
        v.animate().alpha(0f).setDuration(350).withEndAction {
            try { wm?.removeView(v) } catch (_: Exception) {}
        }.start()
    }

    // ------------------------------------------------------------ listening
    private fun listen() {
        if (!active) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this phone.", "en") { endSession() }
            return
        }
        orb?.state = OrbView.State.LISTENING
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) { orb?.level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { orb?.state = OrbView.State.THINKING; orb?.level = 0f }
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { orb?.caption = it }
            }
            override fun onError(e: Int) {
                if (!active) return
                if (listenFails++ < 1) main.postDelayed({ listen() }, 250) else endSession()
            }
            override fun onResults(res: Bundle?) {
                val text = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) { onError(SpeechRecognizer.ERROR_NO_MATCH); return }
                listenFails = 0
                think(text)
            }
        })
        val lang = Prefs.get(this, Prefs.LANG, "hi-IN")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf("en-IN", "hi-IN", "mr-IN"))
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
        r.startListening(i)
        main.removeCallbacks(sessionTimeout)
        main.postDelayed(sessionTimeout, 80_000)
    }

    // ------------------------------------------------------------ thinking
    private fun think(text: String) {
        orb?.caption = text
        orb?.state = OrbView.State.THINKING
        Thread {
            val reply = try {
                Brain.ask(this, text)
            } catch (e: Exception) {
                val msg = if (e.message?.contains("No OpenAI") == true) "Please add your OpenAI key in the app, sir."
                else "I can't reach my brain right now, sir. Check the internet or the API key."
                Reply(msg, "en", org.json.JSONArray(), true)
            }
            main.post { if (active) respond(reply) }
        }.start()
    }

    private fun respond(r: Reply) {
        orb?.caption = r.say
        orb?.state = OrbView.State.SPEAKING
        speak(r.say, r.lang) {
            if (r.actions.length() > 0) {
                // screen-touching commands: reveal the phone first, then act
                hideOrb()
                main.postDelayed({
                    actions.run(r.actions) { endSession() }
                }, 450)
            } else if (r.end) endSession()
            else listen()
        }
    }

    // ------------------------------------------------------------ talking
    private fun speak(text: String, lang: String, done: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady || text.isBlank()) { done(); return }
        val loc = when (lang) {
            "hi" -> Locale("hi", "IN")
            "mr" -> Locale("mr", "IN")
            else -> Locale.UK
        }
        var res = t.setLanguage(loc)
        if (res < 0 && lang == "mr") res = t.setLanguage(Locale("hi", "IN"))
        if (res < 0) t.setLanguage(Locale.UK)
        val id = "u" + System.nanoTime()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { main.post { orb?.level = 0f; done() } }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { main.post { done() } }
            override fun onRangeStart(u: String?, s: Int, e: Int, f: Int) { orb?.level = 0.9f }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        // decay the voice pulse while speaking
        main.post(object : Runnable {
            override fun run() {
                val o = orb ?: return
                if (o.state == OrbView.State.SPEAKING && o.level > 0.1f) o.level *= 0.88f
                if (active) main.postDelayed(this, 60)
            }
        })
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        stopWake()
        recognizer?.destroy()
        tts?.shutdown()
        orb?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
