package com.aura.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.TelephonyManager
import android.view.WindowManager
import android.media.AudioManager
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Always-on Jarvis. Runs as a foreground service so it keeps listening for "Jarvis"
 * even when the app is closed, then shows the orb over everything and talks.
 */
class JarvisService : Service() {

    companion object {
        const val ACTION_STOP = "com.aura.jarvis.STOP"
        const val ACTION_TEST = "com.aura.jarvis.TEST"
        const val ACTION_BDAY = "com.aura.jarvis.BDAY"
        const val ACTION_DEPLOY = "com.aura.jarvis.DEPLOY"
        @Volatile var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var wakeRec: SpeechRecognizer? = null
    private var wakeLoop = false
    private val wakeRestart = Runnable { listenForWake() }
    private val wakeWords = listOf("jarvis", "jarvish", "jarwis", "jarvas", "जार्विस", "जारविस", "जर्विस", "जार्विश", "जारवीस", "जर्वीस", "जार्विज", "जार्वेस", "जारवेस", "जार्वीस")
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wm: WindowManager? = null
    private var orb: OrbView? = null
    private var wake: PowerManager.WakeLock? = null
    private var active = false
    private var listenFails = 0
    private lateinit var actions: Actions

    // phone-call state
    private var phoneReceiverOn = false
    private var inCall = false
    private var ringing = false
    private var ringNumber: String? = null
    private var callSession = false

    // 3D HUD state
    private var awaitingHud = false
    private var awaitingPin = false
    private var pinTries = 0
    private var hudOpen = false

    // birthday
    private var birthdayOn = false

    private val sessionTimeout = Runnable { endSession() }

    private val yesWords = listOf("yes", "yeah", "yep", "open", "ok", "okay", "sure", "haan", "han", "ha", "kar", "karo", "kholo", "khol", "हाँ", "हां", "हा", "खोलो", "खोल", "ओपन", "करो", "कर दो", "ठीक", "होय", "उघडा", "उघड", "चालू")
    private val noWords = listOf("no", "nope", "nahi", "nahin", "mat", "cancel", "नहीं", "नही", "नको", "नाही", "रहने दो", "रहने")
    private val closeWords = listOf("close", "stop", "exit", "band", "बंद", "बन्द", "हटाओ", "बंध", "थांबा", "बस")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        actions = Actions(this)
        try {   // older builds could leave volumes muted
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0)
            am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
        } catch (_: Exception) {}
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setPitch(0.85f)
                tts?.setSpeechRate(0.97f)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        startInForeground()
        running = true
        if (!phoneReceiverOn) registerPhone()
        if (!wakeLoop && !inCall) startWakeWord()
        if (!birthdayOn) { birthdayOn = true; main.postDelayed(birthdayLoop, 5_000) }
        when (intent?.action) {
            ACTION_TEST -> main.postDelayed({ beginSession() }, 400)
            ACTION_BDAY -> main.postDelayed({ beginSession(wishText(true), "", true) }, 400)
            ACTION_DEPLOY -> main.postDelayed({
                beginSession(Pair("", lk()), "", false) { runDeploy() }
            }, 400)
        }
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("jarvis", "Jarvis standby", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is online")
            .setContentText("Say \"Hey Jarvis\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1, n)
    }

    // ------------------------------------------------------------ helpers
    private fun lk(): String = when (Prefs.get(this, Prefs.LANG, "hi-IN")) {
        "hi-IN" -> "hi"
        "mr-IN" -> "mr"
        else -> "en"
    }

    private fun L(hi: String, mr: String, en: String): String = when (lk()) {
        "hi" -> hi
        "mr" -> mr
        else -> en
    }

    /** True if any word matches as a whole word (Latin) or as a substring (Devanagari). */
    private fun has(text: String, words: List<String>): Boolean {
        val t = text.lowercase()
        val tokens = t.split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).toSet()
        for (w in words) {
            val ascii = w.all { it.code < 128 }
            if (ascii) {
                if (tokens.contains(w)) return true
            } else if (t.contains(w)) return true
        }
        return false
    }

    private fun armTimeout() {
        main.removeCallbacks(sessionTimeout)
        main.postDelayed(sessionTimeout, if (hudOpen) 600_000L else 80_000L)
    }

    // ------------------------------------------------------------ wake word
    // Offline engine (Vosk + AudioRecord): does not touch audio focus, so Reels/YouTube/music play normally.
    // Android's SpeechRecognizer is only a fallback while the one-time model download is still running.
    private var engine: WakeEngine? = null
    private var downloading = false

    private fun startWakeWord() {
        if (inCall) return
        wakeLoop = true
        if (ModelStore.ready(this)) {
            main.removeCallbacks(wakeRestart)
            recycleWake()
            if (engine == null) {
                updateNote("Say \"Hey Jarvis\"  (offline listening)")
                engine = WakeEngine(this) { engine = null; main.post { if (wakeLoop && !active) beginSession() } }.also { it.start() }
            }
            return
        }
        if (!downloading) {
            downloading = true
            Thread {
                val ok = ModelStore.download(this) { msg -> main.post { updateNote(msg) } }
                main.post {
                    downloading = false
                    if (ok && wakeLoop && !active) startWakeWord()
                }
            }.start()
        }
        listenForWake()   // temporary fallback
    }

    private fun stopWake() {
        wakeLoop = false
        main.removeCallbacks(wakeRestart)
        engine?.stop(); engine = null
        recycleWake()
    }

    private fun muteBeep(on: Boolean) { /* removed: never touch phone volumes */ }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + (if (a[i - 1] == b[j - 1]) 0 else 1))
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** Forgiving match: "jarvis", "jarves", "garvis", "jar vis", "जार्वेस" ... all count. */
    private fun isWake(text: String): Boolean {
        val s = text.lowercase()
        if (wakeWords.any { s.contains(it) }) return true
        val tokens = s.split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }
        for (i in tokens.indices) {
            val w = tokens[i]
            if (w.length in 4..9 && "jgdchtzy".indexOf(w[0]) >= 0 && lev(w, "jarvis") <= 2) return true
            if (i + 1 < tokens.size) {
                val joined = w + tokens[i + 1]
                if (joined.length in 5..9 && "jgd".indexOf(w[0]) >= 0 && lev(joined, "jarvis") <= 1) return true
            }
            val deva = w.any { it in '\u0900'..'\u097F' }
            if (deva && w.length in 3..9 && "जझयग".indexOf(w[0]) >= 0 && w.contains('व') && w.contains('र') &&
                (w.contains('स') || w.contains('श') || w.contains('ज'))) return true
        }
        return false
    }

    private fun heardWake(b: Bundle?): Boolean {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return false
        return list.any { isWake(it) }
    }

    private fun scheduleWakeRestart(ms: Long) {
        main.removeCallbacks(wakeRestart)
        main.postDelayed(wakeRestart, ms)
    }

    private fun recycleWake() {
        try { wakeRec?.destroy() } catch (_: Exception) {}
        wakeRec = null
    }

    private val wakeListener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rms: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onPartialResults(p: Bundle?) {
            if (wakeLoop && !active && heardWake(p)) main.post { beginSession() }
        }
        override fun onResults(res: Bundle?) {
            if (wakeLoop && !active && heardWake(res)) main.post { beginSession() }
            else scheduleWakeRestart(30)
        }
        override fun onError(e: Int) {
            if (!wakeLoop || active) return
            if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                updateNote("Allow the microphone permission in the app"); return
            }
            if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                scheduleWakeRestart(30)           // normal silence: listen again immediately, same recogniser
            } else if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == 10) {
                recycleWake(); scheduleWakeRestart(1500)
            } else {
                recycleWake(); scheduleWakeRestart(400)
            }
        }
    }

    private fun listenForWake() {
        if (!wakeLoop || active) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNote("Speech recognition not available on this phone"); return
        }
        val r: SpeechRecognizer = wakeRec ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(wakeListener)
            wakeRec = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try { r.startListening(i) } catch (_: Exception) { recycleWake(); scheduleWakeRestart(1000) }
    }

    private fun updateNote(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        nm.notify(1, n)
    }

    // ------------------------------------------------------------ phone calls
    private fun registerPhone() {
        val f = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(phoneReceiver, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(phoneReceiver, f)
            phoneReceiverOn = true
        } catch (_: Exception) {}
    }

    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val st = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            when (st) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    if (!num.isNullOrBlank()) ringNumber = num
                    ringing = true
                    main.removeCallbacks(ringRunnable)
                    main.postDelayed(ringRunnable, 900)
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                    ringing = false
                    main.removeCallbacks(ringRunnable)
                    inCall = true
                    if (active) endSession()
                    stopWake()
                }
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    ringing = false
                    ringNumber = null
                    main.removeCallbacks(ringRunnable)
                    if (inCall) {
                        inCall = false
                        if (!active) startWakeWord()
                    } else if (active && callSession) endSession()
                }
            }
        }
    }

    private val ringRunnable = Runnable {
        if (ringing && !active) {
            val who = nameFor(ringNumber)
            val line = L(
                "सर, $who का कॉल आ रहा है। क्या मैं उठाऊँ?",
                "सर, $who चा कॉल येत आहे. मी उचलू का?",
                "Sir, $who is calling. Shall I pick up?"
            )
            callSession = true
            beginSession(Pair(line, lk()),
                "An incoming phone call from $who is ringing right now. If the user says pick up / answer / uthao / haan, return the answer_call action (add speaker if they ask for it). If they say reject / cut / nahi / disconnect, return end_call.")
        }
    }

    private fun nameFor(number: String?): String {
        if (number.isNullOrBlank()) return L("कोई अनजान नंबर", "एक अनोळखी नंबर", "an unknown number")
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: number
            }
        } catch (_: Exception) {}
        return number
    }

    // ------------------------------------------------------------ birthday
    private val birthdayLoop = object : Runnable {
        override fun run() {
            if (!active && !inCall) {
                val w = dueWish()
                if (w != null) beginSession(w, "", true)
            }
            main.postDelayed(this, 60_000)
        }
    }

    private fun dueWish(): Pair<String, String>? {
        val b = Prefs.birthday(this) ?: return null
        val cal = Calendar.getInstance()
        if (cal.get(Calendar.DAY_OF_MONTH) != b[0] || cal.get(Calendar.MONTH) + 1 != b[1]) return null
        if (cal.get(Calendar.HOUR_OF_DAY) < 7) return null
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
        if (Prefs.get(this, Prefs.WISHED) == today) return null
        Prefs.put(this, Prefs.WISHED, today)
        return wishText(true)
    }

    private fun wishText(sayAge: Boolean): Pair<String, String> {
        val name = Prefs.get(this, Prefs.OWNER, "Aditya").ifBlank { "boss" }
        val b = Prefs.birthday(this)
        val age = if (sayAge && b != null && b[2] > 1900) Calendar.getInstance().get(Calendar.YEAR) - b[2] else 0
        return when (lk()) {
            "hi" -> ("जन्मदिन की ढेर सारी शुभकामनाएँ $name सर! " +
                (if (age > 0) "आज आप $age साल के हो गए। " else "") +
                "मुझ जार्विस की तरफ़ से बहुत बहुत बधाई। आपका दिन शानदार रहे!") to "hi"
            "mr" -> ("वाढदिवसाच्या हार्दिक शुभेच्छा $name सर! " +
                (if (age > 0) "आज तुम्ही $age वर्षांचे झालात. " else "") +
                "जार्विसकडून खूप खूप अभिनंदन. तुमचा दिवस छान जावो!") to "mr"
            else -> ("Happy birthday, $name sir! " +
                (if (age > 0) "You are $age today. " else "") +
                "Wishing you an absolutely fantastic day from all of us at J.A.R.V.I.S.") to "en"
        }
    }

    // ------------------------------------------------------------ session
    private fun beginSession(
        greeting: Pair<String, String>? = null,
        context: String = "",
        celebrate: Boolean = false,
        after: (() -> Unit)? = null
    ) {
        if (active) return
        active = true
        listenFails = 0
        awaitingHud = false
        hudOpen = false
        stopWake()
        Brain.forget()
        Brain.context = context

        @Suppress("DEPRECATION")
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "jarvis:wake"
        ).also { it.acquire(120_000) }

        showOrb()
        var g = greeting
        var cel = celebrate
        if (g == null) {
            val w = dueWish()
            if (w != null) { g = w; cel = true }
        }
        if (g == null) {
            g = when (Prefs.get(this, Prefs.LANG, "hi-IN")) {
                "hi-IN" -> "जी सर?" to "hi"
                "mr-IN" -> "हो सर?" to "mr"
                else -> listOf("Yes, sir?", "At your service.", "Online and ready, sir.").random() to "en"
            }
        }
        orb?.celebrate = cel
        orb?.caption = g.first
        orb?.state = OrbView.State.SPEAKING
        speak(g.first, g.second) { if (after != null) after() else listen() }
        armTimeout()
    }

    private fun endSession() {
        if (!active) return
        main.removeCallbacks(sessionTimeout)
        recognizer?.destroy(); recognizer = null
        tts?.stop()
        hideOrb()
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        active = false
        awaitingHud = false
        awaitingPin = false
        hudOpen = false
        callSession = false
        Brain.context = ""
        startWakeWord()
    }

    // ------------------------------------------------------------ overlay
    private fun showOrb() {
        if (orb != null) return
        if (!Settings.canDrawOverlays(this)) return
        val v = OrbView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )
        lp.alpha = 1f
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        v.setOnClickListener { endSession() }   // tap anywhere to dismiss
        v.alpha = 0f
        try {
            wm?.addView(v, lp)
            v.animate().alpha(1f).setDuration(350).start()
            orb = v
        } catch (_: Exception) {}
    }

    private fun hideOrb() {
        val v = orb ?: return
        orb = null
        v.animate().alpha(0f).setDuration(300).withEndAction {
            try { wm?.removeView(v) } catch (_: Exception) {}
        }.start()
    }

    // ------------------------------------------------------------ listening
    private fun listen() {
        if (!active) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this phone.", "en") { endSession() }
            return
        }
        orb?.state = OrbView.State.LISTENING
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) { orb?.level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { orb?.state = OrbView.State.THINKING; orb?.level = 0f }
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                if (awaitingPin) orb?.caption = "• • • •"
                else p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { orb?.caption = it }
            }
            override fun onError(e: Int) {
                if (!active) return
                if (hudOpen || awaitingHud || (listenFails++ < 1)) main.postDelayed({ listen() }, 300) else endSession()
            }
            override fun onResults(res: Bundle?) {
                val text = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) { onError(SpeechRecognizer.ERROR_NO_MATCH); return }
                listenFails = 0
                think(text)
            }
        })
        val lang = Prefs.get(this, Prefs.LANG, "hi-IN")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf("en-IN", "hi-IN", "mr-IN"))
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
        r.startListening(i)
        armTimeout()
    }

    // ------------------------------------------------------------ 3D HUD
    private fun runDeploy() {
        if (!active) return
        awaitingHud = false
        hudOpen = false
        orb?.mode = OrbView.Mode.DEPLOY
        orb?.hudTarget = 0f
        val steps = listOf(
            L("थ्री डी एच यू डी डिप्लॉय हो रही है सर।",
              "थ्री डी एच यू डी डिप्लॉय होत आहे सर.",
              "Deploying the 3D HUD now, sir.") to 0.3f,
            L("प्रोसेसिंग चालू है।",
              "प्रोसेसिंग सुरू आहे.",
              "Processing has started.") to 0.6f,
            L("और कुछ आपको चाहिए सर?",
              "तुम्हाला आणखी काही हवे आहे का सर?",
              "Do you need anything else, sir?") to 0.82f,
            L("डिप्लॉयमेंट सौ प्रतिशत पूरा हो चुका है सर। थ्री डी एच यू डी डिप्लॉय हो चुकी है। क्या मैं इसे ओपन करूँ?",
              "डिप्लॉयमेंट शंभर टक्के पूर्ण झाले आहे सर. थ्री डी एच यू डी डिप्लॉय झाली आहे. मी ती उघडू का?",
              "Deployment is one hundred percent complete, sir. The 3D HUD is ready. Shall I open it?") to 1f
        )
        deployStep(steps, 0)
    }

    private fun deployStep(steps: List<Pair<String, Float>>, i: Int) {
        if (!active) return
        if (i >= steps.size) {
            awaitingHud = true
            listen()
            return
        }
        orb?.hudTarget = steps[i].second
        orb?.caption = steps[i].first
        orb?.state = OrbView.State.SPEAKING
        speak(steps[i].first, lk()) { deployStep(steps, i + 1) }
    }

    private fun openHud() {
        if (!active) return
        awaitingHud = false
        hudOpen = true
        orb?.mode = OrbView.Mode.HUD
        val s = L("थ्री डी एच यू डी खुल गई है सर। मैं आपके आदेश का इंतज़ार कर रहा हूँ।",
                  "थ्री डी एच यू डी उघडली आहे सर. मी तुमच्या आदेशाची वाट पाहतो आहे.",
                  "The 3D HUD is open, sir. Awaiting your orders.")
        orb?.caption = s
        orb?.state = OrbView.State.SPEAKING
        speak(s, lk()) { listen() }
        armTimeout()
    }

    private fun closeHud() {
        if (!active) return
        hudOpen = false
        orb?.mode = OrbView.Mode.NORMAL
        val s = L("ठीक है सर, एच यू डी बंद कर रहा हूँ।", "ठीक आहे सर, एच यू डी बंद करतो आहे.", "Closing the HUD, sir.")
        orb?.caption = s
        speak(s, lk()) { endSession() }
    }

    private fun declineHud() {
        if (!active) return
        awaitingHud = false
        orb?.mode = OrbView.Mode.NORMAL
        val s = L("ठीक है सर। जब भी ज़रूरत हो बताइए।", "ठीक आहे सर. गरज असेल तेव्हा सांगा.", "Understood, sir. Just say the word.")
        orb?.caption = s
        speak(s, lk()) { endSession() }
    }

    /** Commands we handle on the phone itself (fast, and they work even without ChatGPT). */
    private fun localCommand(text: String): Boolean {
        val t = text.lowercase()
        val deploy = has(t, listOf("deploy", "deployed", "deploying", "डिप्लॉय", "डेप्लॉय", "डिप्लोय", "डिप्लाय"))
        val hud = has(t, listOf("hud", "hood", "3d", "एचयूडी", "हुड", "एच यू डी", "थ्री डी"))
        if (deploy && hud) { runDeploy(); return true }
        if (awaitingHud) {
            if (has(t, noWords)) { declineHud(); return true }
            if (has(t, yesWords)) { openHud(); return true }
            awaitingHud = false
        }
        if (hudOpen && has(t, closeWords)) { closeHud(); return true }
        if (has(t, listOf("unlock", "अनलॉक", "अनलाॅक", "अनलोक", "अन्लॉक"))) { startUnlock(); return true }
        if (has(t, listOf("lock", "लॉक", "लाॅक")) && !hudOpen) { lockPhone(); return true }
        return false
    }

    // ------------------------------------------------------------ lock / unlock by voice
    private val wordDigits = mapOf(
        "zero" to '0', "oh" to '0', "one" to '1', "won" to '1', "two" to '2', "to" to '2', "too" to '2', "three" to '3',
        "four" to '4', "for" to '4', "five" to '5', "six" to '6', "seven" to '7', "eight" to '8', "ate" to '8', "nine" to '9',
        "शून्य" to '0', "ज़ीरो" to '0', "जीरो" to '0', "एक" to '1', "दो" to '2', "दोन" to '2', "तीन" to '3', "चार" to '4',
        "पांच" to '5', "पाँच" to '5', "पाच" to '5', "छह" to '6', "छः" to '6', "छे" to '6', "सहा" to '6', "सात" to '7',
        "आठ" to '8', "नौ" to '9', "नऊ" to '9'
    )

    private fun parsePin(text: String): String {
        val sb = StringBuilder()
        for (tok in text.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }) {
            if (tok.all { Character.isDigit(it) }) {
                for (c in tok) sb.append(Character.digit(c, 10))
            } else wordDigits[tok]?.let { sb.append(it) }
        }
        return sb.toString()
    }

    private fun lockPhone() {
        val hands = JarvisAccessibilityService.instance
        val s = when {
            hands == null -> L("सर, पहले Accessibility में Jarvis Hands चालू कीजिए।", "सर, आधी Accessibility मध्ये Jarvis Hands चालू करा.", "Please turn on Jarvis Hands in Accessibility first, sir.")
            else -> L("फ़ोन लॉक कर रहा हूँ सर।", "फोन लॉक करतो आहे सर.", "Locking the phone, sir.")
        }
        orb?.caption = s
        speak(s, lk()) {
            hideOrb()
            main.postDelayed({
                hands?.lockScreen()
                endSession()
            }, 500)
        }
    }

    private fun startUnlock() {
        if (JarvisAccessibilityService.instance == null) {
            val s = L("सर, पहले Accessibility में Jarvis Hands चालू कीजिए।", "सर, आधी Accessibility मध्ये Jarvis Hands चालू करा.", "Please turn on Jarvis Hands in Accessibility first, sir.")
            orb?.caption = s
            speak(s, lk()) { endSession() }
            return
        }
        pinTries = 0
        askPin()
    }

    private fun askPin() {
        awaitingPin = true
        val s = L("जी सर, कृपया अपना पिन बोलिए।", "हो सर, कृपया तुमचा पिन सांगा.", "Certainly, sir. Please say your PIN.")
        orb?.caption = s
        speak(s, lk()) { listen() }
    }

    private fun handlePin(text: String) {
        awaitingPin = false
        if (has(text, listOf("cancel", "stop", "nahi", "no", "नहीं", "नही", "रहने", "नको", "नाही"))) {
            val s = L("ठीक है सर, अनलॉक रद्द किया।", "ठीक आहे सर, अनलॉक रद्द केले.", "Unlock cancelled, sir.")
            orb?.caption = s
            speak(s, lk()) { endSession() }
            return
        }
        val pin = parsePin(text)
        if (pin.length < 4) {
            if (++pinTries >= 3) {
                val s = L("माफ़ कीजिए सर, पिन समझ नहीं आया।", "माफ करा सर, पिन समजला नाही.", "Sorry sir, I couldn't catch the PIN.")
                orb?.caption = s
                speak(s, lk()) { endSession() }
            } else {
                val s = L("पिन साफ़ नहीं सुनाई दिया, फिर से बोलिए।", "पिन नीट ऐकू आला नाही, पुन्हा सांगा.", "I didn't catch that. Please say the PIN again.")
                awaitingPin = true
                orb?.caption = s
                speak(s, lk()) { listen() }
            }
            return
        }
        orb?.caption = "• • • •"
        val s = L("अनलॉक कर रहा हूँ सर।", "अनलॉक करतो आहे सर.", "Unlocking, sir.")
        speak(s, lk()) {
            hideOrb()
            main.postDelayed({
                JarvisAccessibilityService.instance?.unlockWithPin(pin) { endSession() }
                    ?: endSession()
            }, 400)
        }
    }

    // ------------------------------------------------------------ thinking
    private fun think(text: String) {
        if (awaitingPin) { handlePin(text); return }
        orb?.caption = text
        if (localCommand(text)) return
        orb?.state = OrbView.State.THINKING
        Thread {
            val reply = try {
                Brain.ask(this, text)
            } catch (e: Exception) {
                val msg = if (e.message?.contains("No OpenAI") == true) "Please add your OpenAI key in the app, sir."
                else "I can't reach my brain right now, sir."
                Reply(msg, "en", JSONArray(), true, "[" + (e.message ?: e.javaClass.simpleName).take(240) + "]")
            }
            main.post { if (active) respond(reply) }
        }.start()
    }

    private fun respond(r: Reply) {
        var deploy = false; var open = false; var close = false
        val rest = JSONArray()
        for (i in 0 until r.actions.length()) {
            val a = r.actions.optJSONObject(i) ?: continue
            when (a.optString("type")) {
                "deploy_hud" -> deploy = true
                "open_hud" -> open = true
                "close_hud" -> close = true
                else -> rest.put(a)
            }
        }
        if (deploy) { runDeploy(); return }
        if (open) { openHud(); return }
        if (close) { closeHud(); return }

        orb?.caption = if (r.note.isBlank()) r.say else r.say + "\n" + r.note
        orb?.state = OrbView.State.SPEAKING
        speak(r.say, r.lang) {
            if (rest.length() > 0) {
                // screen-touching commands: reveal the phone first, then act
                hideOrb()
                main.postDelayed({
                    actions.run(rest) { endSession() }
                }, 450)
            } else if (r.end && !hudOpen) endSession()
            else listen()
        }
    }

    // ------------------------------------------------------------ talking
    private fun speak(text: String, lang: String, done: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady || text.isBlank()) { done(); return }
        val loc = when (lang) {
            "hi" -> Locale("hi", "IN")
            "mr" -> Locale("mr", "IN")
            else -> Locale.UK
        }
        var res = t.setLanguage(loc)
        if (res < 0 && lang == "mr") res = t.setLanguage(Locale("hi", "IN"))
        if (res < 0) t.setLanguage(Locale.UK)
        val id = "u" + System.nanoTime()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { main.post { orb?.level = 0f; done() } }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { main.post { done() } }
            override fun onRangeStart(u: String?, s: Int, e: Int, f: Int) { orb?.level = 0.9f }
        })
        val rc = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        if (rc != TextToSpeech.SUCCESS) { main.post { done() }; return }
        // decay the voice pulse while speaking
        main.post(object : Runnable {
            override fun run() {
                val o = orb ?: return
                if (o.state == OrbView.State.SPEAKING && o.level > 0.1f) o.level *= 0.88f
                if (active) main.postDelayed(this, 60)
            }
        })
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        if (phoneReceiverOn) { try { unregisterReceiver(phoneReceiver) } catch (_: Exception) {} }
        stopWake()
        recognizer?.destroy()
        tts?.shutdown()
        orb?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
