package com.aura.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

/** Setup screen: key, personal details, permissions, start/stop. Everything is built in code (no XML layout). */
class MainActivity : Activity() {

    private val orange = Color.rgb(255, 140, 0)
    private lateinit var status: TextView
    private lateinit var openai: EditText
    private lateinit var owner: EditText
    private lateinit var model: EditText
    private lateinit var baseUrl: EditText
    private lateinit var birthday: EditText
    private lateinit var people: EditText
    private lateinit var facts: EditText
    private lateinit var lang: Spinner
    private lateinit var muteBox: CheckBox
    private val langCodes = listOf("hi-IN", "en-IN", "mr-IN")
    private val langNames = listOf("Hindi + English mix (recommended)", "English", "Marathi")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(orange); textSize = 13f; setPadding(0, dp(14), 0, dp(4))
    }

    private fun field(hint: String, value: String, secret: Boolean = false) = EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        setSingleLine(); textSize = 14f
        if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        backgroundTintList = android.content.res.ColorStateList.valueOf(orange)
    }

    private fun multi(hint: String, value: String) = EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        minLines = 3; gravity = Gravity.TOP; textSize = 14f
        backgroundTintList = android.content.res.ColorStateList.valueOf(orange)
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.BLACK); isAllCaps = false
        backgroundTintList = android.content.res.ColorStateList.valueOf(orange)
        setOnClickListener { onClick() }
    }

    private fun svc(action: String? = null) {
        val i = Intent(this, JarvisService::class.java)
        if (action != null) i.action = action
        startForegroundService(i)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(40))
        }
        col.addView(TextView(this).apply {
            text = "J.A.R.V.I.S"; setTextColor(orange); textSize = 30f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; letterSpacing = 0.3f
        })
        col.addView(TextView(this).apply {
            text = "Say \"Hey Jarvis\" even when this app is closed."; setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER; textSize = 13f
        })

        col.addView(label("1 · AI BRAIN (free option: Groq, no card needed)"))
        openai = field("API key (Groq: gsk_...  /  OpenAI: sk-...)", Prefs.get(this, Prefs.OPENAI), true)
        owner = field("Your name", Prefs.get(this, Prefs.OWNER, "Aditya"))
        model = field("ChatGPT model", Prefs.get(this, Prefs.MODEL, "gpt-4o-mini"))
        baseUrl = field("API base URL", Prefs.get(this, Prefs.BASEURL, "https://api.openai.com/v1"))
        listOf(openai, owner, model, baseUrl).forEach { col.addView(it) }
        col.addView(button("Use FREE Groq (fills URL + model)") {
            baseUrl.setText("https://api.groq.com/openai/v1")
            model.setText("llama-3.3-70b-versatile")
            toast("Now paste your Groq key (starts with gsk_) in the first box, then Save everything")
        })
        col.addView(button("Use OpenAI (paid)") {
            baseUrl.setText("https://api.openai.com/v1")
            model.setText("gpt-4o-mini")
        })

        col.addView(label("2 · ABOUT YOU (Jarvis remembers this)"))
        birthday = field("My birthday: DD-MM-YYYY (e.g. 25-12-2005)", Prefs.get(this, Prefs.BIRTHDAY))
        col.addView(birthday)
        col.addView(label("My people - one per line:  nickname = saved contact name"))
        people = multi("best friend = Aradhya Patil\nmom = Mummy\nbrother = Rohan", Prefs.get(this, Prefs.PEOPLE))
        col.addView(people)
        col.addView(label("More about me (Jarvis also saves things you tell it to remember)"))
        facts = multi("I love anime edits\nMy YouTube channel is Aura_Edits", Prefs.get(this, Prefs.FACTS))
        col.addView(facts)

        col.addView(label("Listening language"))
        lang = Spinner(this)
        lang.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langNames)
        lang.setSelection(langCodes.indexOf(Prefs.get(this, Prefs.LANG, "hi-IN")).coerceAtLeast(0))
        col.addView(lang)
        muteBox = CheckBox(this).apply {
            text = "Silence the listening beep (also mutes notification sounds while Jarvis runs)"
            setTextColor(Color.LTGRAY); textSize = 12f
            isChecked = Prefs.get(this@MainActivity, "mute") == "1"
            buttonTintList = android.content.res.ColorStateList.valueOf(orange)
        }
        col.addView(muteBox)
        col.addView(button("Save everything") { save(); toast("Saved") })

        col.addView(label("3 · PERMISSIONS (do each one, top to bottom)"))
        col.addView(button("Allow microphone, calls, contacts, notifications") {
            val p = mutableListOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS,
                Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG
            )
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        })
        col.addView(button("Allow display over other apps (the orb)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("Turn on Accessibility → Jarvis Hands") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("Never sleep: allow background battery") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; setPadding(0, dp(12), 0, dp(4)) }
        col.addView(status)

        col.addView(label("4 · GO"))
        col.addView(button("START JARVIS (always listening)") {
            save()
            Prefs.put(this, "autostart", "1")
            svc()
            toast("Jarvis is online. You can close this app and say Hey Jarvis.")
            refresh()
        })
        col.addView(button("Test the orb now (no wake word)") { save(); svc(JarvisService.ACTION_TEST) })
        col.addView(button("Test: deploy 3D HUD") { save(); svc(JarvisService.ACTION_DEPLOY) })
        col.addView(button("Test: birthday wish") { save(); svc(JarvisService.ACTION_BDAY) })
        col.addView(button("Stop Jarvis") {
            Prefs.put(this, "autostart", "0")
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
            refresh()
        })

        col.addView(TextView(this).apply {
            text = "\nTry saying: \"Hey Jarvis, call my best friend\" · \"Hey Jarvis, deploy 3D HUD\" · \"Hey Jarvis, pick up the call\" · " +
                "\"Hey Jarvis, remember Rohan is my brother\".\n\n" +
                "Vivo tip: Settings → Battery → Background power consumption → Jarvis → Allow. " +
                "Also: Settings → Apps → Autostart → Jarvis ON, and lock Jarvis in the recent apps screen."
            setTextColor(Color.GRAY); textSize = 12f
        })

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun save() {
        Prefs.put(this, Prefs.OPENAI, openai.text.toString().trim())
        Prefs.put(this, Prefs.OWNER, owner.text.toString().trim())
        Prefs.put(this, Prefs.MODEL, model.text.toString().trim())
        Prefs.put(this, Prefs.BASEURL, baseUrl.text.toString().trim())
        Prefs.put(this, Prefs.BIRTHDAY, birthday.text.toString().trim())
        Prefs.put(this, Prefs.PEOPLE, people.text.toString().trim())
        Prefs.put(this, Prefs.FACTS, facts.text.toString().trim())
        Prefs.put(this, "mute", if (muteBox.isChecked) "1" else "0")
        Prefs.put(this, Prefs.LANG, langCodes[lang.selectedItemPosition])
    }

    private fun refresh() {
        fun ok(b: Boolean) = if (b) "✅" else "❌"
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val call = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val answer = checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
        val overlay = Settings.canDrawOverlays(this)
        val hands = JarvisAccessibilityService.instance != null
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val battery = pm.isIgnoringBatteryOptimizations(packageName)
        status.text = "${ok(mic)} Microphone   ${ok(call)} Calls   ${ok(answer)} Answer calls\n" +
            "${ok(overlay)} Orb overlay   ${ok(hands)} Hands (accessibility)\n" +
            "${ok(battery)} Background allowed   ${ok(JarvisService.running)} Jarvis running"
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); refresh()
    }
}
